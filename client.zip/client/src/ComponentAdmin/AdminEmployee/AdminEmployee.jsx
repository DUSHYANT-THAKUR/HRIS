import React, { useEffect, useState } from "react";
import axios from "axios";
import baseUrl from "../../ComponentEmployee/config/baseUrl";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { Dialog, DialogContent, DialogTitle } from "@mui/material";
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import Paginations from "../../ComponentEmployee/CommonComponentEmployee/Pagination/Pagination";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import * as XLSX from "xlsx";
import Search from "../../ComponentEmployee/CommonComponentEmployee/Search/Search";
function AdminEmployee() {

  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const auth = localStorage.getItem("user");
  const [team, setTeam] = useState([]);
  const [searchItem, setSearchItem] = useState("");
  const [page, setPage] = useState(1);
  
  
  const [totalPage, setTotalPage] = useState(1);
  const [message, setMessage] = useState("");
  const fetchTeam = async () => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      let data = {
        page: page,
        searchitem: searchItem,
      };
      let result = await axios.post(`${baseUrl}/fetchTeam`, data, config);
      setTeam(result.data.result);
      setTotalPage(result.data.totalPage);
      setMessage(result.data.message);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const deleteTeam = async (id) => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      let data = {
        id: id
      };
      let result = await axios.post(`${baseUrl}/deleteTeam`, data, config);
      console.log(result.data);
      fetchTeam()

    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }
  useEffect(() => {
    fetchTeam();
  }, [page, searchItem]);
  return (
    <div className="content-container mt-4 me-4">
      <div className="col-lg-2 col-6 col-md-3 mt-1">
        <div>
          <Dialog
            open={open}
            onClose={handleClose}
            fullWidth={false}
            maxWidth={"md"}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            PaperProps={{
              style: {
                top: "0",
                margin: "0",
                borderRadius: "30px",
              },
            }}
          >
            <button
              style={{
                position: "absolute",
                top: "10px",
                right: "10px",
                background: "#38d39f",
                border: "none",
                borderRadius: "50%",
                cursor: "pointer",
                padding: "5px",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                width: "32px",
                height: "32px",
              }}
              onClick={handleClose}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="feather feather-x"
                style={{
                  display: "block",
                  width: "100%",
                  height: "100%",
                }}
              >
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
            <DialogTitle
              id="alert-dialog-title"
              style={{ fontWeight: "700", fontSize: "20px" }}
            >
              Add Task
            </DialogTitle>
            <DialogContent>
              <div className="row">
                <div className="col-12 swapBox">
                  <form className="row justify-content-around">
                    <div className="row">
                      <div className="col-4">
                        <label>Department</label>
                      </div>
                      <div className="col-8">
                        <select
                          class="form-select mb-3"
                          aria-label="Default select example"
                        >
                          <option selected>Select One</option>
                          <option value="1">One</option>
                          <option value="2">Two</option>
                          <option value="3">Three</option>
                        </select>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-4">
                        <label>Assign To Member</label>
                      </div>
                      <div className="col-8">
                        <select
                          class="form-select mb-3"
                          aria-label="Default select example"
                        >
                          <option selected>Select One</option>
                          <option value="1">One</option>
                          <option value="2">Two</option>
                          <option value="3">Three</option>
                        </select>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-4">
                        <label>Task Subject</label>
                      </div>
                      <div className="col-8">
                        <input
                          type="text"
                          placeholder="Task subject"
                          className="form-control mb-3"
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-4">
                        <label>Task Description</label>
                      </div>
                      <div className="col-8">
                        <textarea
                          type="text"
                          placeholder="Type here"
                          className="form-control mb-3"
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-4">
                        <label>Priority Level</label>
                      </div>
                      <div className="col-8 mb-3">
                        <select
                          class="form-select"
                          aria-label="Default select example"
                        >
                          <option selected>Open this select menu</option>
                          <option value="1">One</option>
                          <option value="2">Two</option>
                          <option value="3">Three</option>
                        </select>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-4">
                        <label>Date</label>
                      </div>
                      <div className="col-8">
                        <input
                          type="date"
                          className="form-control mb-3"
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-4">
                        <label>Project Status</label>
                      </div>
                      <div className="col-8">
                        <select
                          class="form-select mb-3"
                          aria-label="Default select example"
                        >
                          <option selected>Select One</option>
                          <option value="1">One</option>
                          <option value="2">Two</option>
                          <option value="3">Three</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <button
                        className="btn btn me-2"
                        style={{
                          background: "#38d39f",
                          color: "#fff",
                          marginLeft: "auto",
                          display: "block",
                          width: "100px",
                        }}
                        type="submit"
                      >
                        Create
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="row">
        <h5 style={{ fontWeight: "700" }}>Team Members</h5>
      </div>
      <div className="row mt-2">
        <div className="row search-container ms-1">
          <div className="col-3">
            <Search serchItem={searchItem} setSearchItem={setSearchItem} />
          </div>








          <div className="col-9 text-end">
            <button className="btn ms-2 text-light" style={{ background: "#27851E", }}>Download</button>
          </div>
        </div>
      </div>
      <div className="row">
        <TableContainer className="tablecontainer2 mt-4">
          <Table
            sx={{ minWidth: 650 }}
            className="table-striped table-hover"
            aria-label="simple table"
          >
            <TableHead>
              <TableRow>
                <TableCell className="tablefont-align">Employee ID</TableCell>
                <TableCell className="tablefont-align">Members</TableCell>
                <TableCell className="tablefont-align">Gender</TableCell>
                <TableCell className="tablefont-align">Department</TableCell>
                <TableCell className="tablefont-align">Email Id</TableCell>
                <TableCell className="tablefont-align">Slack Message</TableCell>
                <TableCell className="tablefont-align">DOJ</TableCell>
                <TableCell className="tablefont-align">DOB</TableCell>
                <TableCell className="tablefont-align">Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {team.map((item, index) => (
                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  key={index}
                >
                  <TableCell align="center">{item.empid}</TableCell>
                  <TableCell align="center text-capitalize"><b>{item.name}</b></TableCell>
                  <TableCell align="center">{item.gender}</TableCell>
                  <TableCell align="center">
                    {item.level == "1"
                      ? "Junior Sales/ Junior BDM"
                      : item.level == "2"
                        ? "Sales Manager/BDM"
                        : item.level == "3"
                          ? "Senior Sales Manager /Senior BDM"
                          : item.level == "4"
                            ? "Head of Sales & BD"
                            : "NOT DEFINED"}
                  </TableCell>
                  <TableCell align="center">
                    <Link to={`mailto:${item.email}`}>{item.email}</Link>
                  </TableCell>
                  <TableCell align="center">
                    <button
                      className="btn btn-success"
                      style={{ padding: "4px", fontSize: "small", background: "" }}
                      onClick={() =>
                        window.open(item.slack_profile_url, "_blank")
                      }
                    >
                      Slack Profile
                    </button>
                  </TableCell>
                  <TableCell align="center">{item.doj}</TableCell>
                  <TableCell align="center">{item.dob}</TableCell>
                  <TableCell className="text-end">
                    <div className="dropdown">
                      <Link
                        className="btn rounded btn-sm font-sm action-button"
                        style={{ color: 'green' }}
                        to="#"
                        data-bs-toggle="dropdown"
                      >
                        <MoreHorizIcon />
                      </Link>
                      <div className="dropdown-menu">
                        {/* <Link className="dropdown-item" to="#" onClick={handleClickOpen}>
                          Assign Task
                        </Link> */}
                        <Link
                          className="dropdown-item text-danger"
                          to="#"
                          onClick={() => deleteTeam(item.id)}
                        >
                          Delete
                        </Link>

                      </div>
                    </div>
                  </TableCell>

                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
      <div className="row">
        <Paginations
          page={page}
          setPage={setPage}
          totalPage={totalPage}
          message={message}
        />
      </div>
    </div>
  );
}
export default AdminEmployee;