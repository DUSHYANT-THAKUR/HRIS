import React, { useEffect, useState } from "react";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { Link } from "react-router-dom";
import baseUrl from "../../ComponentEmployee/config/baseUrl";
import axios from "axios";
import Search from "../../ComponentEmployee/CommonComponentEmployee/Search/Search";
import { Dialog, DialogContent, DialogTitle } from "@mui/material";

import PaginationComp from "../../ComponentEmployee/CommonComponentEmployee/Pagination/Pagination";

const AdminLeave = () => {
  const auth = localStorage.getItem("admin");
  const [open, setOpen] = useState(false);
  const [searchVal, setSearchval] = useState("");
  const [message, setMessage] = useState("");
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [data, setData] = useState([])

  let fetchLeave = async () => {
    try {
      const values = { page, searchItem: searchVal }
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(`${baseUrl}/DefaultLeave`, values, config);
      setData(result.data.result)
      setMessage(result.data.message);
      setTotalPage(Number(result.data.totalPage));
    } catch (error) {
      console.log(error);
    }
  }
  let updateLeaveStatus = async (status, requested_Id) => {
    try {
      const values = { status: status, requestedid: requested_Id }
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(`${baseUrl}/updateleave`, values, config);
      console.log(result.data);

      fetchLeave()
    } catch (error) {
      console.log(error);
    }
  }
  useEffect(() => {
    fetchLeave()
  }, [searchVal, page])

  return (
    <div>
      <div className="card mt-4 table-container">
        <header className="table-header p-4">
          <h5 className="card-title" style={{ fontWeight: 600 }}>
            Leave Approval
          </h5>
          <div className="row gx-3">
            <div className="col-lg-4 col-md-6 me-auto">
              <Search searchVal={searchVal} setSearchItem={setSearchval} />
            </div>
            <div className="col-lg-2 col-6 col-md-3 mt-1">
              <select className="form-select p-2">
                <option>Status</option>
                <option>Done</option>
                <option>In Progress</option>
                <option>Cancelled</option>
              </select>
            </div>

          </div>
        </header>
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-start">
              <thead>
                <tr>
                  <th>Requested ID</th>
                  <th>Employee Id</th>
                  <th scope="col">Name</th>
                  <th scope="col">FromDate</th>
                  <th scope="col">ToDate</th>
                  <th scope="col">Reason</th>
                  <th scope="col">Status</th>

                </tr>
              </thead>

              <tbody>
                {data.length > 0 ? (
                  data.map((item) => (
                    <tr key={item.id}>
                      <td>{item.requested_Id}</td>
                      <td>{item.empid}</td>
                      <td>
                        <b className="text-capitalize">{item.name}</b>
                      </td>
                      <td>{item.from_date}</td>
                      <td>{item.to_date}</td>
                      <td style={{ maxWidth: '200px', whiteSpace: 'normal', wordWrap: 'break-word' }}>
                        {item.Reason}
                      </td>
                      <td>
                        <td>
                          <button 
                            className={`btn 
      ${item.status === 0 ? "btn-danger " :
                                item.status === 1 ? "btn-success " :
                                  "btn-warning "}`}
                            aria-label={item.status === 0 ? "Decline" : item.status === 1 ? "Approved" : "Pending"}
                            onClick={() => updateLeaveStatus(item.status, item.requested_Id)}
                          >
                            {item.status === 0 ? "Decline" : item.status === 1 ? "Approved" : "Pending"}
                          </button>
                        </td>

                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No tasks found.
                    </td>
                  </tr>
                )}
              </tbody>

            </table>
          </div>
        </div>

      </div>
      <div>
        <PaginationComp
          setPage={setPage}
          page={page}
          totalPage={totalPage}
          message={message}
        />
      </div>
    </div>

  );
};

export default AdminLeave;
