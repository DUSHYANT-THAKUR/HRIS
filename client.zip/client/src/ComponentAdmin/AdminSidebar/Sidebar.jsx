import * as React from 'react';
import { styled, useTheme,ThemeProvider, createTheme } from '@mui/material/styles';
import './Sidebar.css'
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import CssBaseline from '@mui/material/CssBaseline';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import EventIcon from '@mui/icons-material/Event';
import TaskIcon from '@mui/icons-material/Task';
import IconButton from '@mui/material/IconButton';
import LockResetIcon from '@mui/icons-material/LockReset';
import AdminLogin from '../Login/AdminLogin'
import MenuIcon from '@mui/icons-material/Menu';
import LogoutIcon from '@mui/icons-material/Logout';
import PaidIcon from '@mui/icons-material/Paid';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import DashboardIcon from '@mui/icons-material/Dashboard';
import MailIcon from '@mui/icons-material/Mail';
import logo from './bankconnect.6939ad8ad77f7b4fbcd4.png'
import Dashboard from '../Dashboard/Dashboard';
import { Link, Route, Routes, useNavigate } from 'react-router-dom';
import { Switch } from '@mui/material';
import ChangePassword from '../ChangePassword/ChangePassword';
import Task from '../Task/Task';
import Calendar from '../../ComponentAdmin/MyCalendar/Calendar'
import RequestTask from '../AdminEmployee/AdminEmployee';
import AdminEmployee from '../AdminEmployee/AdminEmployee';
import Commission from '../Commission/Commission'
import EmployeeAttendance from '../EmployeeAttendance/EmployeeAttendance';
import Leave from '../Leave/AdminLeave'
import VendorDetails from "../VendorDetails/Vendor"
const drawerWidth = 240;

const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: `-${drawerWidth}px`,
    variants: [
      {
        props: ({ open }) => open,
        style: {
          transition: theme.transitions.create('margin', {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
          }),
          marginLeft: 0,
        },
      },
    ],
  }),
);

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  variants: [
    {
      props: ({ open }) => open,
      style: {
        width: `calc(100% - ${drawerWidth}px)`,
        marginLeft: `${drawerWidth}px`,
        transition: theme.transitions.create(['margin', 'width'], {
          easing: theme.transitions.easing.easeOut,
          duration: theme.transitions.duration.enteringScreen,
        }),
      },
    },
  ],
}));

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

export default function Sidebar() {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const navigate = useNavigate(); 
  
  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  }; 
  const handleLogout=()=>{
    localStorage.clear("admin");
    localStorage.clear("role");
    navigate('/Admin');
  }
  return (
    <Box sx={{ display: 'flex' }} className="hero">
    <CssBaseline />
    <AppBar position="fixed" open={open} id='navbar'>
      <Toolbar>
        <IconButton
          color="inherit"
          aria-label="open drawer"
          onClick={handleDrawerOpen}
          edge="start"
          sx={[
            {
              mr: 2,
            },
            open && { display: 'none' },
          ]}
        >
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" noWrap component="div">
          Admin Panel
        </Typography>
      </Toolbar>
    </AppBar>
    <Drawer
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
        },
      }}
      variant="persistent"
      anchor="left"
      open={open}
    >
      <DrawerHeader>
        <img src={logo} width={180}/>
        <IconButton onClick={handleDrawerClose} className='sidebar-toggle-icon '>
          {theme.direction === 'ltr' ? <ChevronLeftIcon /> : <ChevronRightIcon />}
        </IconButton>
      </DrawerHeader>
      <Divider />
      <List>
        <ListItem disablePadding>
          <ListItemButton
           component={Link} 
           to="/Admin/dashboard" 
           className='list-item'>
            <ListItemIcon>
              <DashboardIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Dashboard"  className='pb-2'/>
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/Today'sAttendence" className='list-item'>
            <ListItemIcon>
              <CalendarTodayIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Today's Attendence" className='pb-2'/>
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/Commission" className='list-item'>
            <ListItemIcon>
              <PaidIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Commissions" className='pb-2'/>
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/VendorIntegration" className='list-item'>
            <ListItemIcon>
             <EventIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Vendor Integration" className='pb-2' />
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/employee-details" className='list-item'>
            <ListItemIcon>
           <ManageAccountsIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Employee Details" className='pb-2'/>
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/request-task" className='list-item'>
            <ListItemIcon>
             <TaskIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Request Task" className='pb-2'/>
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/Calendar" className='list-item'>
            <ListItemIcon>
             <EventIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Calendar" className='pb-2' />
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/leave" className='list-item'>
            <ListItemIcon>
             <EventIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Leave Approval" className='pb-2' />
          </ListItemButton>
        </ListItem>
      </List>
      <Divider />
      <List>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin/change-password" className='list-item'>
            <ListItemIcon>
          <LockResetIcon className='admin-icon' />
            </ListItemIcon>
            <ListItemText primary="Change Password" className='pb-2'/>
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/Admin" className='list-item'>
            <ListItemIcon>
             <LogoutIcon className='admin-icon'/>
            </ListItemIcon>
            <ListItemText primary="Logout" onClick={handleLogout}/>
          </ListItemButton>
        </ListItem>
      </List>
    </Drawer>
    <Main open={open} className='admin-main'>
      <DrawerHeader />
      <Routes>
        <Route path="/Admin/dashboard" element={<Dashboard/>} />
         <Route path='/Admin/Calendar' element={<Calendar/>}/>
        <Route path='/Admin/request-task' element={<Task/>}/>
        <Route path='/Admin/employee-details' element={<AdminEmployee/>}/>
         <Route path="/Admin/change-password" element={<ChangePassword/>} />
         <Route path="/Admin/Today'sAttendence" element={<EmployeeAttendance/>}/>
         <Route path="/Admin/leave" element={<Leave/>}/>
         <Route path="/Admin/Commission" element={<Commission/>}/>
         <Route path="/Admin/VendorIntegration" element={<VendorDetails />}/>
      </Routes>
    </Main>
  </Box>
  );
}



// <Box sx={{ display: 'flex' }} >
    //   <CssBaseline />
    //   <AppBar position="fixed" open={open}>
    //     <Toolbar>
    //       <IconButton
    //         color="inherit"
    //         aria-label="open drawer"
    //         onClick={handleDrawerOpen}
    //         edge="start"
    //         sx={[
    //           {
    //             mr: 2,
    //           },
    //           open && { display: 'none' },
    //         ]}
    //       >
    //         <MenuIcon />
    //       </IconButton>
    //       <Typography variant="h6" noWrap component="div">
    //         Persistent drawer
    //       </Typography>
    //     </Toolbar>
    //   </AppBar>
    //   <Drawer
    //     sx={{
    //       width: drawerWidth,
    //       flexShrink: 0,
    //       '& .MuiDrawer-paper': {
    //         width: drawerWidth,
    //         boxSizing: 'border-box',
    //       },
    //     }}
    //     variant="persistent"
    //     anchor="left"
    //     open={open}
    //   >
    //     <DrawerHeader>
    //       <img src={logo} width={180}/>
    //       <IconButton onClick={handleDrawerClose}>
    //         {theme.direction === 'ltr' ? <ChevronLeftIcon /> : <ChevronRightIcon />}
    //       </IconButton>
    //     </DrawerHeader>
    //     <Divider />
    //     <List >
    //       {['Dashboard', 'Sub Admin', 'Send email', 'Drafts'].map((text, index) => (
    //         <ListItem key={text} disablePadding >
    //           <ListItemButton >
    //             <ListItemIcon >
    //               {index % 2 === 0 ? <InboxIcon className='text-light'/> : <MailIcon  className='text-light'/>}
    //             </ListItemIcon>
    //             <ListItemText primary={text} />
    //           </ListItemButton>
    //         </ListItem>
    //       ))}
    //     </List>
    //     <Divider />
    //     <List>
    //       {['ChangePassword', 'Logout'].map((text, index) => (
    //         <ListItem key={text} disablePadding>
    //           <ListItemButton>
    //             <ListItemIcon>
    //               {index % 2 === 0 ? <InboxIcon  className='text-light'/> : <MailIcon className='text-light'/>}
    //             </ListItemIcon>
    //             <ListItemText primary={text} />
    //           </ListItemButton>
    //         </ListItem>
    //       ))}
    //     </List>
    //   </Drawer>
    //   <Main open={open}>
    //     <DrawerHeader />
    //     <Typography sx={{ marginBottom: 2 }}>
    //       <Dashboard/>
    //     </Typography>
    //     <Typography sx={{ marginBottom: 2 }}>

    //       Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim quod corrupti doloremque laboriosam sequi ducimus temporibus ipsum eligendi praesentium, beatae explicabo omnis cupiditate minus accusantium laborum illum ullam impedit voluptate blanditiis quasi placeat architecto cum! Eum beatae ducimus autem omnis praesentium a sit corporis, quos architecto eveniet consequuntur harum dignissimos, reiciendis et minima alias nobis accusantium soluta fugiat animi quidem molestias veniam! Itaque perspiciatis magni quia illo accusantium error earum deserunt hic unde, amet officiis adipisci ex, ipsam, porro culpa odit esse aut sed expedita natus. Aliquid quas consequatur autem, explicabo nihil incidunt cum dolor, esse dolore nostrum ipsum necessitatibus.lorem300
    //       Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis laborum in asperiores, assumenda modi quam sint, nisi aut vel, ad voluptate reiciendis voluptatem. Ex obcaecati illo voluptates facere saepe? Voluptatibus, sit esse distinctio eos deserunt, ipsa beatae, inventore repudiandae molestiae maxime voluptatum similique? Quo autem ex voluptatem aliquid rem amet harum inventore pariatur aperiam, ipsum neque excepturi voluptates nulla quos itaque iure obcaecati aspernatur quaerat sint? Aut neque dolore magnam porro. Expedita laboriosam perferendis est quas? Architecto veritatis atque, fugiat laboriosam porro repellat inventore eius soluta nam aliquid aperiam tempore reiciendis voluptates officiis ipsa ut alias deleniti non voluptatibus minus sunt. Quae illum rem accusamus sapiente velit, ab, harum ad quo pariatur voluptates debitis eligendi quas esse iure officia neque ipsa. Impedit inventore vitae voluptatibus a totam, dolores incidunt nulla consequuntur iste illum accusantium quam laboriosam non dolorum eligendi voluptate temporibus ipsa quae enim perferendis ex itaque corporis? Officia ut veritatis reprehenderit quas similique doloribus provident natus vitae accusamus. Cum accusamus sunt ipsa, incidunt nobis enim modi quod, molestiae, facilis optio laborum atque maxime ipsam ipsum id error natus vero minus asperiores adipisci. Earum beatae dignissimos culpa tempora numquam impedit ipsam illum, sint necessitatibus, aspernatur, voluptatibus asperiores nesciunt dolore aliquam!
    //       Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem quisquam fugiat magnam consequatur similique officia neque architecto maxime at minima esse possimus libero et, ea maiores animi id delectus obcaecati, nesciunt molestias voluptates enim. Quo voluptatem quas laborum. Tempore laborum, cumque quod nemo sapiente eum vero labore quaerat cum sequi, quos ipsam consectetur corrupti recusandae laboriosam. Harum est nemo obcaecati? Provident quisquam cumque molestias quibusdam earum nobis repellendus, fugiat delectus officiis quidem vel odio repellat. Officia obcaecati pariatur hic deleniti! Fuga commodi debitis placeat officiis! Facere suscipit aliquid debitis soluta vel officiis tempora, nobis labore ad, accusamus omnis possimus eaque quas rerum temporibus fuga quaerat cum nulla id unde consequuntur amet minima voluptatum! Eveniet dolor nesciunt minus dolores officiis aliquid tempore nisi laudantium ad sit accusamus rerum accusantium error voluptate similique eum suscipit, praesentium itaque at eos dicta ipsum mollitia sequi omnis. Provident nihil iusto sequi sint illo possimus ipsum eius facilis saepe ipsa nulla quos nisi, cum, adipisci dolores quibusdam quas libero sit aliquid tempora! Exercitationem nemo facere hic dignissimos voluptatum! Ex excepturi cum dolorem libero corrupti laboriosam obcaecati, itaque deserunt officia impedit nostrum? Dolore enim optio itaque sint consequuntur perferendis, vero, debitis natus molestias excepturi aspernatur animi repellat doloribus laboriosam beatae ex omnis dolores facilis quaerat id. Nemo ipsum numquam soluta sit itaque nisi, dolore nesciunt iure placeat ratione deleniti iusto praesentium, dicta quam accusamus eaque temporibus fugiat similique error labore corrupti voluptatibus obcaecati nihil maiores? Numquam voluptas sed aliquid sit, odit similique temporibus error doloremque, facilis amet eum, sapiente sequi dignissimos modi quisquam iste obcaecati aperiam deserunt tempora eaque quibusdam quas nihil maxime. Debitis vitae consectetur fugit tempore eius suscipit ullam id, veritatis velit tenetur qui maxime laboriosam fuga assumenda molestiae eos consequuntur, similique accusamus rem. Recusandae reprehenderit culpa nulla quisquam iure corrupti doloremque nam. Tempore, possimus!
    //     </Typography>
    //   </Main>
    // </Box>