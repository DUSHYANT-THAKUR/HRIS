import React, { useEffect, useState } from "react";
import baseUrl from "../../ComponentEmployee/config/baseUrl";
import axios from "axios";
import { Divider } from "@mui/material";
const ResourceAssetst = () => {
    const auth = localStorage.getItem('admin');
    const [data, setData] = useState([]);
    const [name, setName] = useState([])
    const [commissions, setCommissions] = useState({
        January: 0,
        February: 0,
        March: 0,
        April: 0,
        May: 0,
        June: 0,
        July: 0,
        August: 0,
        September: 0,
        October: 0,
        November: 0,
        December: 0,
    });
    const [statuses, setStatuses] = useState({
        January: 0,
        February: 0,
        March: 0,
        April: 0,
        May: 0,
        June: 0,
        July: 0,
        August: 0,
        September: 0,
        October: 0,
        November: 0,
        December: 0,
    });
    const getQuarterTotal = (months) => months.reduce((sum, month) => sum + parseFloat(commissions[month]), 0);
    const fetchreport = async (id) => {
        try {
            let value={id:id}
            const config = {
                headers: {
                    "Content-type": "application/json",
                    Accept: "application/json",
                    Authorization: `Bearer ${auth}`,
                },
            };
            const result = await axios.post(`${baseUrl}/quarterCommissionAdmin`,value, config);
            const fetchedData = result.data.result;
            setData(fetchedData);
            // Set commissions and statuses based on fetched data
            const newCommissions = { ...commissions };
            const newStatuses = { ...statuses };
            fetchedData.forEach(item => {
                newCommissions[item.month] = parseFloat(item.commission);
                newStatuses[item.month] = item.status;
            });
            setCommissions(newCommissions);
            setStatuses(newStatuses);
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };
    const fetchname = async () => {
        try {
            const config = {
                headers: {
                    "Content-type": "application/json",
                    Accept: "application/json",
                    Authorization: `Bearer ${auth}`,
                },
            };
            const result = await axios.post(`${baseUrl}/fetchEmpName`, {}, config);
            const fetchedData = result.data.result;
            
           
            
            console.log(fetchedData);
            setName(fetchedData);
            
           

        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };
    useEffect(() => {

        }, []);
    return (
        <div className="container-fluid">

            <div className="row">
                <div className="col-lg-12 subnavbar mt-4 ps-0 pe-0">
                    <div className="d-flex justify-content-between align-items-center">
                        <h5 className="ms-2 mt-3 mb-3 main-heading">Quarterly Commission</h5>
                        <div className="dropdown me-2">
                            <button
                                className="btn btn-secondary dropdown-toggle"
                                type="button"
                                id="dropdownMenuButton"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                                onClick={() => fetchname()}
                            >
                                Select Name
                            </button>
                            <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                {name.map((item, index) => (
                                    <li key={index}>
                                        <a className="dropdown-item" onClick={()=>fetchreport(item.id)}>
                                            {item.name}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>

                    </div>

                    <Divider />
                    <div className="table-responsive" style={{ overflowY: "hidden" }}>
                        <table className="table">
                            <thead>
                                <tr>
                                    <th scope="col">Month</th>
                                    <th scope="col">Commission</th>
                                    <th scope="col">Quarterly Commission</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/* Q1: January - March */}
                                <tr>
                                    <td>January</td>
                                    <td>{commissions.January}$</td>
                                    <td rowSpan="3" style={{ verticalAlign: "middle", fontWeight: "bold" }}>
                                        {getQuarterTotal(['January', 'February', 'March'])}$
                                    </td>
                                </tr>
                                <tr>
                                    <td>February</td>
                                    <td>{commissions.February}$</td>
                                </tr>
                                <tr>
                                    <td>March</td>
                                    <td>{commissions.March}$</td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        (January-March)
                                    </td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        <button
                                            className={`btn ms-3 ${statuses.January === 2 || statuses.February === 2 || statuses.March === 2
                                                ? "btn-danger"
                                                : statuses.January === 1 && statuses.February === 1 && statuses.March === 1
                                                    ? "btn-success"
                                                    : "btn-warning"
                                                }`}
                                        >
                                            {statuses.January === 2 || statuses.February === 2 || statuses.March === 2
                                                ? "No Commission for this Month"
                                                : statuses.January === 1 && statuses.February === 1 && statuses.March === 1
                                                    ? "Paid"
                                                    : "Unpaid"}
                                        </button>
                                    </td>
                                </tr>
                                {/* Q2: April - June */}
                                <tr>
                                    <td>April</td>
                                    <td>{commissions.April}$</td>
                                    <td rowSpan="3" style={{ verticalAlign: "middle", fontWeight: "bold" }}>
                                        {getQuarterTotal(['April', 'May', 'June'])}$
                                    </td>
                                </tr>
                                <tr>
                                    <td>May</td>
                                    <td>{commissions.May}$</td>
                                </tr>
                                <tr>
                                    <td>June</td>
                                    <td>{commissions.June}$</td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        (April-June)
                                    </td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        <button
                                            className={`btn ms-3 ${statuses.April === 2 || statuses.May === 2 || statuses.June === 2
                                                ? "btn-danger"    // Red for "No Commission for this Month"
                                                : statuses.April === 1 && statuses.May === 1 && statuses.June === 1
                                                    ? "btn-success"   // Green for "Paid"
                                                    : "btn-warning"   // Yellow for "Unpaid"
                                                }`}
                                        >
                                            {statuses.April === 2 || statuses.May === 2 || statuses.June === 2
                                                ? "No Commission for this Month"
                                                : statuses.April === 1 && statuses.May === 1 && statuses.June === 1
                                                    ? "Paid"
                                                    : "Unpaid"}
                                        </button>
                                    </td>
                                </tr>
                                {/* Q3: July - September */}
                                <tr>
                                    <td>July</td>
                                    <td>{commissions.July}$</td>
                                    <td rowSpan="3" style={{ verticalAlign: "middle", fontWeight: "bold" }}>
                                        {getQuarterTotal(['July', 'August', 'September'])}$
                                    </td>
                                </tr>
                                <tr>
                                    <td>August</td>
                                    <td>{commissions.August}$</td>
                                </tr>
                                <tr>
                                    <td>September</td>
                                    <td>{commissions.September}$</td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        (July-September)
                                    </td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        <button
                                            className={`btn ms-3 ${statuses.July === 2 || statuses.August === 2 || statuses.September === 2
                                                ? "btn-danger"    // Red for "No Commission for this Month"
                                                : statuses.July === 1 && statuses.August === 1 && statuses.September === 1
                                                    ? "btn-success"   // Green for "Paid"
                                                    : "btn-warning"   // Yellow for "Unpaid"
                                                }`}
                                        >
                                            {statuses.July === 2 || statuses.August === 2 || statuses.September === 2
                                                ? "No Commission for this Month"
                                                : statuses.July === 1 && statuses.August === 1 && statuses.September === 1
                                                    ? "Paid"
                                                    : "Unpaid"}
                                        </button>
                                    </td>
                                </tr>
                                {/* Q4: October - December */}
                                <tr>
                                    <td>October</td>
                                    <td>{commissions.October}$</td>
                                    <td rowSpan="3" style={{ verticalAlign: "middle", fontWeight: "bold" }}>
                                        {getQuarterTotal(['October', 'November', 'December'])}$
                                    </td>
                                </tr>
                                <tr>
                                    <td>November</td>
                                    <td>{commissions.November}$</td>
                                </tr>
                                <tr>
                                    <td>December</td>
                                    <td>{commissions.December}$</td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        (October-December)
                                    </td>
                                </tr>
                                <tr>
                                    <td colSpan="3" style={{ textAlign: "center", fontWeight: "bold" }}>
                                        <button
                                            className={`btn ms-3 ${statuses.October === 2 || statuses.November === 2 || statuses.December === 2
                                                ? "btn-danger"    // Red for "No Commission for this Month"
                                                : statuses.October === 1 && statuses.November === 1 && statuses.December === 1
                                                    ? "btn-success"   // Green for "Paid"
                                                    : "btn-warning"   // Yellow for "Unpaid"
                                                }`}
                                        >
                                            {statuses.October === 2 || statuses.November === 2 || statuses.December === 2
                                                ? "No Commission for this Month"
                                                : statuses.October === 1 && statuses.November === 1 && statuses.December === 1
                                                    ? "Paid"
                                                    : "Unpaid"}
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>
    );
};
export default ResourceAssetst;