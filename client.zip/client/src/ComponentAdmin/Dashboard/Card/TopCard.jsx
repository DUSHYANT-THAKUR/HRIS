import React, { useEffect, useState } from "react";
import './Card.css'
import FavoriteIcon from "@mui/icons-material/Favorite";
import LocalMallIcon from '@mui/icons-material/LocalMall';
import ShoppingBagIcon from '@mui/icons-material/ShoppingBag';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import CallMadeIcon from '@mui/icons-material/CallMade';
import CallReceivedIcon from '@mui/icons-material/CallReceived';
import baseUrl from "../../../ComponentEmployee/config/baseUrl";
import axios from "axios";

const TopCard = () => {
  const auth = localStorage.getItem('admin')
  const [totalEmp,setTotalEmp] = useState("");
  const [totalTodayPresent,setTotalTodayPresent] = useState("");
  const [lastMonthCommission,setLastMonthCommission] = useState("");

  const fetchTotalEmpData =async ()  =>{
    try {
     const config = {
       headers: {
         "content-type": "multipart/form-data",
         Authorization: `Bearer ${auth}`,
       },
     };
     let result = await axios.post(`${baseUrl}/totalEmployee`, {}, config);
     console.log("all emp",result.data.result[0].totalEmployee)
     setTotalEmp(result.data.result[0].totalEmployee)
   } catch (error) {
     console.log(error);
   }
  }
  const fetchTodayTotalPresentData =async ()  =>{
    try {
     const config = {
       headers: {
         "content-type": "multipart/form-data",
         Authorization: `Bearer ${auth}`,
       },
     };
     let result = await axios.post(`${baseUrl}/TodayPresentEmployee`, {}, config)
     console.log("total present",result.data.result[0].todayPresent)
     setTotalTodayPresent(result.data.result[0].todayPresent)
   } catch (error) {
     console.log(error);
   }
  }
  const fetchLastMonthCommissionData =async ()  =>{
    try {
     const config = {
       headers: {
         "content-type": "multipart/form-data",
         Authorization: `Bearer ${auth}`,
       },
     };
     let result = await axios.post(`${baseUrl}/lastMonthCommission`, {}, config);
     console.log("fetch last monnt",result.data.result[0].commission)
     setLastMonthCommission(result.data.result[0].commission)
   } catch (error) {
     console.log(error);
   }
  }
  useEffect(()=>
  {
fetchTotalEmpData();
fetchTodayTotalPresentData();
fetchLastMonthCommissionData();
  },[])
  const cardsData = [
    {
      id: 1,
      title: "Total Employee",
      value: `${totalEmp}`,
      rate: "28.4%",
      isUp: true,
      icon: <FavoriteIcon />,
    },
    {
      id: 2,
      title: "Today's Present",
      value: `${totalTodayPresent}`,
      rate: "12.6%",
      isUp: false,
      icon: <LocalMallIcon/>,
    },
    // {
    //   id: 3,
    //   title: "Last Month Commission",
    //   value: "756",
    //   rate: "3.1%",
    //   isUp: true,
    //   icon: <ShoppingBagIcon/>,
    // },
    {
      id: 4,
      title: "Last Month Commission",
      value: `${lastMonthCommission}`,
      rate: "11.3%",
      isUp: true,
      icon: <AttachMoneyIcon/>,
    },
  ];
  return (
    <div className="container-fluid">
      <div className="row">
        {cardsData.map((item, index) => {
          return (
            <div className="col-lg-4 col-md-6 col-sm-12 mb-1" key={index}>
              <div className="card border-0 " style={{backgroundColor:"transparent"}}>
                <div className="card-body top-card ">
                  <div className="card-title-wrapper ">
                    <div className="top-card-title">
                     <p id="card-icon">{item.icon}</p>
                      <p className="card-title">{item.title}</p>
                    </div>
                    <div>
                      <MoreHorizIcon />
                    </div>
                  </div>
                  <div className="d-flex card-value">
                    <h4 className="card-text" id="top-card-text">{item.value}</h4>
                   
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TopCard;
