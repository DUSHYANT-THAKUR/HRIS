import React, { useEffect, useState } from "react";
import "./Card.css";
import img1 from './img/avatar2.jpg';
import img2 from './img/avatar3.jpg';
import img3 from './img/avatar4.jpg';
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import baseUrl from "../../../ComponentEmployee/config/baseUrl";
import axios from "axios";

const HiresAndEvents = () => {
  const auth = localStorage.getItem('admin')
  const[eventData,setEventData] = useState([]);
  const [hireData,setHireData] = useState([]);
  // const HireData=[
  //   {
  //     imgUrl:img1,
  //     name:"Karen Jones",
  //     title:"Sales and Accounts"
  //   },
  //   {
  //     imgUrl:img2,
  //     name:"Karen Jones",
  //     title:"Business Development"
  //   },
  //   {
  //     imgUrl:img3,
  //     name:"Karen Jones",
  //     title:"IT and Security"
  //   }
  // ]
  const newHireData =async ()  =>{
    try {
     const config = {
       headers: {
         "content-type": "multipart/form-data",
         Authorization: `Bearer ${auth}`,
       },
     };
     let result = await axios.post(`${baseUrl}/newHire`, {}, config)
     console.log("88888888888888",result.data.result)
     setHireData(result.data.result)
   } catch (error) {
     console.log(error);
   }
  }
  const upcomingEventData =async ()  =>{
    try {
     const config = {
       headers: {
         "content-type": "multipart/form-data",
         Authorization: `Bearer ${auth}`,
       },
     };
     let result = await axios.post(`${baseUrl}/upcomingFiveHolidays`, {}, config)
     console.log("my result is here",result.data.result)
        setEventData(result.data.result)
   } catch (error) {
     console.log(error);
   }
  }
  // const EventsData=[
  //   {
  //     day:"Today",
  //     title:"Lorem ipsum dolor sit amet consectetur",
  //   },
  //   {
  //     day:"Today",
  //     title:"Lorem ipsum dolor sit amet consectetur",
  //   },
  //   {
  //     day:"Today",
  //     title:"Lorem ipsum dolor sit amet consectetur",
  //   },
  //   {
  //     day:"Today",
  //     title:"Lorem ipsum dolor sit amet consectetur",
  //   },
  //   {
  //     day:"Today",
  //     title:"Lorem ipsum dolor sit amet consectetur",
  //   }
  // ]
  useEffect(()=>{
    upcomingEventData()
    newHireData()
  },[])
  return (
    <div className="row mt-5">
      {/* New Hires start */}
      <div className="col-lg-6">
        <div className="card mb-4 hire-activity-card">
          <article className="card-body">
            <h5 className="card-title hire-activity-card-title" >New Hires</h5>
            <div className="new-member-list">
             {hireData.map((item,index)=>{
               return(
                <div className="d-flex align-items-center justify-content-between mb-4" key={index}>
               <div className="d-flex align-items-center">
                 <img
                   className="avatar"
                   src={ `${baseUrl}/${item.profile_img}`}
                   alt=""
                 />
                 <div>
                   <h6>{item.name}</h6>
                   <p className="text-muted font-xs">{item.team}</p>
                 </div>
               </div>
             </div>
               )
             })}
            </div>
          </article>
        </div>
      </div>
      {/* New Hires end */}
      {/* Activities and Events start  */}
      <div className="col-lg-6" style={{height:"60vh"}}>
        <div className="card mb-4 hire-activity-card">
          <article className="card-body">
            <h5 className="card-title hire-activity-card-title">Activities and Events&nbsp;&nbsp;</h5>
            <ul className="verti-timeline list-unstyled font-sm">
           {eventData.map((item, index)=>{
            return(
              <li className="event-list" key={index}>
              <div className="event-timeline-dot">
               <PlayCircleOutlineIcon/>
              </div>
              <div className="media d-flex">
                <div className="me-3">
                  <h6 className="d-flex">
                    <span className="mt-1">{item.start}</span>
                   <ArrowRightAltIcon className="ms-2 right-arrow"/>
                  </h6>
                </div>
                <div className="media-body mt-1" id="activity-para">
                  <div>{item.title}</div>
                </div>
              </div>
            </li>
            )
           })}
              {/* <li class="event-list active">
                <div class="event-timeline-dot">
                  <i class="material-icons md-play_circle_outline font-xxl animation-fade-right"></i>
                </div>
                <div class="media">
                  <div class="me-3">
                    <h6>
                      <span>17 Sept</span>
                      <i class="material-icons md-trending_flat text-brand ml-15 d-inline-block"></i>
                    </h6>
                  </div>
                  <div class="media-body">
                    <div>Debitis nesciunt voluptatum dicta reprehenderit</div>
                  </div>
                </div>
              </li>
              <li class="event-list">
                <div class="event-timeline-dot">
                  <i class="material-icons md-play_circle_outline font-xxl"></i>
                </div>
                <div class="media">
                  <div class="me-3">
                    <h6>
                      <span>13 Sept</span>
                      <i class="material-icons md-trending_flat text-brand ml-15 d-inline-block"></i>
                    </h6>
                  </div>
                  <div class="media-body">
                    <div>Accusamus voluptatibus voluptas.</div>
                  </div>
                </div>
              </li>
              <li class="event-list">
                <div class="event-timeline-dot">
                  <i class="material-icons md-play_circle_outline font-xxl"></i>
                </div>
                <div class="media">
                  <div class="me-3">
                    <h6>
                      <span>05 Sept</span>
                      <i class="material-icons md-trending_flat text-brand ml-15 d-inline-block"></i>
                    </h6>
                  </div>
                  <div class="media-body">
                    <div>At vero eos et accusamus et iusto odio dignissi</div>
                  </div>
                </div>
              </li>
              <li class="event-list">
                <div class="event-timeline-dot">
                  <i class="material-icons md-play_circle_outline font-xxl"></i>
                </div>
                <div class="media">
                  <div class="me-3">
                    <h6>
                      <span>26 Aug</span>
                      <i class="material-icons md-trending_flat text-brand ml-15 d-inline-block"></i>
                    </h6>
                  </div>
                  <div class="media-body">
                    <div>Responded to need &ldquo;Volunteer Activities</div>
                  </div>
                </div>
              </li> */}
            </ul>
          </article>
        </div>
      </div>
    </div>
  );
};

export default HiresAndEvents;
