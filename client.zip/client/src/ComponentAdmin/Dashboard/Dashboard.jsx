import React, { useEffect, useState } from "react";
import TopCard from "./Card/TopCard";
import "../Dashboard/Dashboard.css";
import HiresAndEvents from "./Card/HiresAndEvents";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { Link } from "react-router-dom";
import Button from 'react-bootstrap/Button';
import baseUrl from "../../ComponentEmployee/config/baseUrl";
import { toast } from "react-toastify";
import {
  Dialog,
  DialogTitle,
  IconButton,
  DialogContent,
  DialogContentText,
  Typography,
  DialogActions
} from "@mui/material";
import Form from "react-bootstrap/Form";
import axios from "axios";
const Dashboard = () => {
  const auth = localStorage.getItem("admin");
  const [name, setName] = useState();
  const [task, setTask] = useState([]);
  const [viewTaskRequestDialog, setViewTaskRequestDialog] = useState(false);
  const [editTaskRequestDialog,setEditTaskRequestDialog] = useState(false)
  const handleDialogClose = () => {
    setViewTaskRequestDialog(false);
    setEditTaskRequestDialog(false)
  };
  const fetchData = async () => {
    try {
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };

      let result = await axios.post(`${baseUrl}/fetchEmpName`, {}, config);
      setName(result.data.result);
      console.log(result.data.result);

      let resultTask = await axios.post(`${baseUrl}/fetchEmpTask`, {}, config);
      setTask(resultTask.data.result);
      console.log(resultTask.data.result);
    } catch (error) {
      console.log(error);
    }
  };
  let ViewTaskTaskDialog = ({ open,data }) => (

    <Dialog
      open={open}
      onClose={handleDialogClose}
      aria-describedby="alert-dialog-slide-description"
      disableBackdropClick // Optional: Prevents closing by clicking outside
      sx={{
        "& .MuiBackdrop-root": {
          backgroundColor: "transparent", 
        },
      }}
     
    >
      <div className="p-4" style={{backgroundColor:"#efefef"}}>
      <DialogTitle><Typography variant="h5" component="h2">
View Task
</Typography></DialogTitle>
      <DialogContent className="p-4">
        <DialogContentText id="alert-dialog-slide-description">
          <div className="row mt-0">
            <div className="col-md-6">
              <Form.Label htmlFor="inputPassword5" className="view-label">Task Id</Form.Label>
              <Form.Control
                id="view-input"
                aria-describedby="passwordHelpBlock"
                value={data.task_id}
              />
            </div>
            <div className="col-md-6">
              <Form.Label htmlFor="inputPassword5" className="view-label">Assigned To</Form.Label>
              <Form.Control
                id="view-input"
                aria-describedby="passwordHelpBlock"
                value={data.user_id}
              />
            </div>
          </div>
          <div className="row mt-4">
          <div className="col-md-6">
              <Form.Label htmlFor="inputPassword5" className="view-label">Task Description</Form.Label>
              <Form.Control
                id="view-input"
                aria-describedby="passwordHelpBlock"
                value={data.request_data}
              />
            </div>
            <div className="col-md-6">
              <Form.Label htmlFor="inputPassword5" className="view-label">Status</Form.Label>
              <Form.Control
                id="view-input"
                aria-describedby="passwordHelpBlock"
                value={data.status}
              />
            </div>
          </div>
          <div className="row mt-4">
            <div className="col-md-6">
              <Form.Label htmlFor="inputPassword5" className="view-label">Start Date</Form.Label>
              <Form.Control
                id="view-input"
                aria-describedby="passwordHelpBlock"
                value={data.created_on}
              />
            </div>
            <div className="col-md-6">
              <Form.Label htmlFor="inputPassword5" className="view-label">End Date</Form.Label>
              <Form.Control
                id="view-input"
                aria-describedby="passwordHelpBlock"
                value={"Not Defined"}
              />
            </div>
          </div>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
      <Button variant="primary" onClick={handleDialogClose}>Close</Button>
      </DialogActions>
      </div>
    </Dialog>
  );
//   let EditTaskTaskDialog = ({ open,data }) => (
//     <Dialog
//       open={open}
//       onClose={handleDialogClose}
//       aria-describedby="alert-dialog-slide-description"
//       disableBackdropClick // Optional: Prevents closing by clicking outside
//       sx={{
//         "& .MuiBackdrop-root": {
//           backgroundColor: "transparent", 
//         },
//       }}
     
//     >
//       <div className="p-4" style={{backgroundColor:"#efefef"}}>
//       <DialogTitle><Typography variant="h5" component="h2">
// Edit Task
// </Typography></DialogTitle>
//       <DialogContent className="p-4">
//       <DialogContentText id="alert-dialog-slide-description">
//           <div className="row mt-0">
//             <div className="col-md-6">
//               <Form.Label htmlFor="inputPassword5" className="view-label">Task Id</Form.Label>
//               <Form.Control
//                 id="view-input"
//                 aria-describedby="passwordHelpBlock"
//                 value={data.task_id}
//               />
//             </div>
//             <div className="col-md-6">
//               <Form.Label htmlFor="inputPassword5" className="view-label">Assigned To</Form.Label>
//               <Form.Control
//                 id="view-input"
//                 aria-describedby="passwordHelpBlock"
//                 value={data.user_id}
//               />
//             </div>
//           </div>
//           <div className="row mt-4">
//           <div className="col-md-6">
//               <Form.Label htmlFor="inputPassword5" className="view-label">Task Description</Form.Label>
//               <Form.Control
//                 id="view-input"
//                 aria-describedby="passwordHelpBlock"
//                 value={data.request_data}
//               />
//             </div>
//             <div className="col-md-6">
//               <Form.Label htmlFor="inputPassword5" className="view-label">Status</Form.Label>
//               <Form.Control
//                 id="view-input"
//                 aria-describedby="passwordHelpBlock"
//                 value={data.status}
//               />
//             </div>
//           </div>
//           <div className="row mt-4">
//             <div className="col-md-6">
//               <Form.Label htmlFor="inputPassword5" className="view-label">Start Date</Form.Label>
//               <Form.Control
//                 id="view-input"
//                 aria-describedby="passwordHelpBlock"
//                 value={data.created_on}
//               />
//             </div>
//             <div className="col-md-6">
//               <Form.Label htmlFor="inputPassword5" className="view-label">End Date</Form.Label>
//               <Form.Control
//                 id="view-input"
//                 aria-describedby="passwordHelpBlock"
//                 value={"Not Defined"}
//               />
//             </div>
//           </div>
//         </DialogContentText>
//       </DialogContent>
//       <DialogActions>
//       <Button variant="primary" onClick={handleDialogClose}>Upda</Button>
//       </DialogActions>
//       </div>
//     </Dialog>
//   );
  let deleteTaskRequest = async (taskId)=> {
    const formData = new FormData();
    formData.append("task_id",taskId)
    const config = {
      headers: {
        "content-type": "multipart/form-data",
        Authorization: `Bearer ${auth}`,
      },
    };

    const result = await axios.post(`${baseUrl}/deleteTaskRequest`,formData,config)
if (result.status==200) {
  toast.success(
result.data.message,
    {
      position: "bottom-right",
      autoClose: 2000,
    }
  ); 
  window.location.reload();
} else {
  toast.error("error", {
    position: "bottom-right",
    autoClose: 1000,
  });
}
  }
  useEffect(() => {
    fetchData();
  }, []);
  return (
    <div>
      <TopCard />
      <HiresAndEvents />
      <div className="card mt-4 table-container">
        <header className="table-header p-4">
          <h5 className="card-title" style={{ fontWeight: 600 }}>
            Task Requests
          </h5>
          {/* <div className="row gx-3">
            <div className="col-lg-4 col-md-6 me-auto">
              <input
                className="form-control p-2 mt-1"
                type="text"
                placeholder="Search Task"
              />
            </div>
            <div className="col-lg-2 col-6 col-md-3 mt-1">
              <select className="form-select p-2">
                <option>Status</option>
                <option>Done</option>
                <option>In Progress</option>
                <option>Cancelled</option>
              </select>
            </div>
            <div className="col-lg-2 col-6 col-md-3 mt-1">
              <select className="form-select p-2">
                <option>Show 20</option>
                <option>Show 30</option>
                <option>Show 40</option>
              </select>
            </div>
          </div> */}
        </header>
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-start">
              <thead>
                <tr>
                  <th>Task ID</th>
                  <th scope="col">Assigned To</th>
                  <th scope="col">Task Description</th>
                  <th scope="col">Status</th>
                  <th scope="col">Start Date</th>
                  <th scope="col">End Date</th>
                  <th className="text-end" scope="col">
                    {" "}
                    Action
                  </th>
                </tr>
              </thead>
              {task.map((item) => (
                <tbody>
                  <tr>
                    <td>{item.task_id}</td>
                    <td>
                      <b>{item.user_id}</b>
                    </td>
                    <td>{item.request_data}</td>
                    <td>
                      <span className="badge rounded-pill alert-warning text-warning p-2">
                        In Progress
                      </span>
                    </td>
                    <td>{item.created_on}</td>
                    <td>Not Defined</td>
                    <td className="text-end">
                      <Link
                        className="btn rounded btn-sm font-sm action-button"
                        to="/"
                        data-bs-toggle="dropdown"
                      >
                        <MoreHorizIcon />
                      </Link>
                      <div className="dropdown-menu">
                        <ViewTaskTaskDialog
                          open={viewTaskRequestDialog}
                          // handleClose={handleDialogClose}
                          data = {item}
                        />
                      
                        <Link
                          className="dropdown-item"
                          onClick={() => {
                            setViewTaskRequestDialog(true);
                          }}
                        >
                          View Task Details
                        </Link>
                       
                        <Link className="dropdown-item text-danger" onClick={()=>{
                          deleteTaskRequest(item.task_id)
                        }}>
                          Delete
                        </Link>
                      </div>
                    </td>
                  </tr>
                </tbody>
              ))}
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
