import React, { useState } from "react";
import "./AdminLogin.css"; // Assuming you have the same CSS as in your HTML
import waveImage from "./img/wave.png"; // Import images correctly
import bgImage from "./img/bg.svg";
import { useNavigate } from "react-router-dom";
import ubank from "./img/UBankConnectLogo.svg";
import avatarImage from "./img/avatar.svg";
import baseUrl from "../../ComponentEmployee/config/baseUrl";
import { useStateContext } from "../../context/ContextProvider";
import { toast } from "react-toastify";

// FontAwesome Icons import
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser, faLock } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";

const LoginForm = () => {
  const { setIsLoginUser,setRole } = useStateContext();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [usernameFocus, setUsernameFocus] = useState(false);
  const [passwordFocus, setPasswordFocus] = useState(false);

  const navigate = useNavigate(); // Initialize navigate

  const handleSubmit = (e) => {
    e.preventDefault();

    // Here, you might want to validate the username and password
    console.log("Username:", username);
    console.log("Password:", password);
    let formData = new FormData();
    formData.append("email", username);
    formData.append("password", password);
    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(`${baseUrl}/login`, formData, config)
      .then((response) => {
        // setMessage((message = response.data.message));
        if (response.status==200) {
          toast.success(
            <span style={{ fontWeight: "bold", color: "#2626E8" }}>
              Welcome To Ubankconnect
            </span>,
            {
              position: "top-center",
              autoClose: 2000,
            }
          );
          setTimeout(() => {
            setIsLoginUser(response.data.token);
            localStorage.setItem("admin", response.data.token);
            // setRole(response.data.role)
            localStorage.setItem("role", response.data.role);
            navigate("/Admin/dashboard", { state: { showModal: true } });
          }, 2000);
         
        } else {
          toast.error("error", {
            position: "bottom-right",
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        toast.error("Something went wrong:link::linked_paperclips:", {
          position: "bottom-right",
          autoClose: 1000,
        });
      });
  };
  const handleFocus = (setter) => {
    setter(true);
  };

  const handleBlur = (setter, value) => {
    if (value === "") {
      setter(false);
    }
  };

  return (
    <div>
      <img className="wave" src={waveImage} alt="wave" />
      <div className="container main">
        <div className="img">
          <img src={bgImage} alt="background" />
        </div>
        <div className="ubankLogo position-fixed">
          <img src={ubank} height={60} />
        </div>
        <div className="login-content">
          <form onSubmit={handleSubmit} className="Admin-login-form">
            <img src={avatarImage} alt="avatar" />
            <h2 className="title">Login</h2>

            {/* Username Field */}
            <div className={`input-div one ${usernameFocus ? "focus" : ""} mt-4`}>
              <div className="i">
                <FontAwesomeIcon icon={faUser} />
              </div>
              <div className="div">
                <h5>Username</h5>
                <input
                  type="text"
                  className="input"
                  value={username}
                  onFocus={() => handleFocus(setUsernameFocus)}
                  onBlur={() => handleBlur(setUsernameFocus, username)}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Password Field */}
            <div className={`input-div pass ${passwordFocus ? "focus" : ""}`}>
              <div className="i">
                <FontAwesomeIcon icon={faLock} />
              </div>
              <div className="div">
                <h5>Password</h5>
                <input
                  type="password"
                  className="input"
                  value={password}
                  onFocus={() => handleFocus(setPasswordFocus)}
                  onBlur={() => handleBlur(setPasswordFocus, password)}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <a href="#" id="forget-text" className="mt-2">Forgot Password?</a>

            {/* Submit Button */}
            <input type="submit" className="AdminLogin-btn" value="Login" />
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
