import React, { useEffect, useState } from "react";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { Link, useActionData } from "react-router-dom";
import { Dialog, DialogContent, DialogTitle } from "@mui/material";
import baseUrl from "../../ComponentEmployee/config/baseUrl";
import axios from "axios";
import Search from "../../ComponentEmployee/CommonComponentEmployee/Search/Search";
import PaginationComp from "../../ComponentEmployee/CommonComponentEmployee/Pagination/Pagination"
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

const Vendor = () => {
  const auth = localStorage.getItem("admin");
  const [open, setOpen] = useState(false);
  const [searchItem, setSearchItem] = useState("");
  const [vendor, setVendor] = useState([])
  const [name, setName] = useState([])
  const [message, setMessage] = useState("");
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [AcquiredBy,setAcquiredBy]=useState('')
  const [VendorNameAdmin,setVendorNameAdmin]=useState('')
  const [Type,setType]=useState('')
  const [Currency,setCurrency]=useState('')
  const [PaymentType,setPaymentType]=useState('')
  const [Rate,setRate]=useState('')
  const [Minimum,setMinimum]=useState('')
  const [Maximum,setMaximum]=useState('')
  const [Live,setLive]=useState('')

  const fetchData = async () => {
    try {
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };
      let data = {
        searchItem: searchItem,
        page:page
      };
      let result = await axios.post(`${baseUrl}/fetchEmpName`, {}, config);
      setName(result.data.result)
      console.log(result.data.result)

      let resultTask = await axios.post(`${baseUrl}/defaultVendor`,data, config);
      setVendor(resultTask.data.result)
      setMessage(resultTask.data.message);
      setTotalPage(Number(resultTask.data.totalPage));

      console.log(resultTask.data.result)
    } catch (error) {
      console.log(error);
    }
  }
  const createVendor =async(e) =>{
    e.preventDefault()
    try {
        const config = {
          headers: {
            "content-type": "multipart/form-data",
            Authorization: `Bearer ${auth}`,
          },
        };
        let data = {
          user_id:AcquiredBy,
          VendorName:VendorNameAdmin,
          Type:Type,
          Currency:Currency,
          PaymentType:PaymentType,
          Rate:Rate,
          Minimum:Minimum,
          Maximum:Maximum,
          liveFrom:Live
          
        }
  
        let resultTask = await axios.post(`${baseUrl}/createVendor`,data, config);
       
  
        console.log(resultTask.data.result)
        setOpen(false);
        window.location.reload()
      } catch (error) {
        console.log(error);
      }
  }
  const deleteTeam = async (id) => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      let data = {
        id: id
      };
      let result = await axios.post(`${baseUrl}/deleteVendor`, data, config);
      console.log(result.data);
      fetchData()

    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }
  let updateLeaveStatus = async (status, id) => {
    try {
      const values = { status: status, id: id }
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(`${baseUrl}/updateVendorStatus`, values, config);
      console.log(result.data);
      fetchData()
    } catch (error) {
      console.log(error);
    }
  }


  useEffect(() => { 
    fetchData()
  }, [searchItem,page]);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  return (
    <div>
    <div className="card mt-1 table-container">
      <header className="table-header p-4">
        <h5 className="card-title" style={{ fontWeight: 600 }}>
          Vendor Details
        </h5>
        <div className="row search-container">
          <div className="col-lg-5 col-md-6 me-auto">
            {/* <div className="row search-container ms-1"> */}
            <div className="col-5">
              <Search serchItem={searchItem} setSearchItem={setSearchItem} />
            </div>
          </div>
          <div className="col-lg-2 col-6 col-md-3 mt-1">
            <div>
              <button
                style={{
                  background: "#27851e",
                  borderRadius: "30px",
                  color: "#fff",
                  width: "120px",
                  height: "36px",
                  cursor: "pointer",
                  border: "none",
                }}
                onClick={handleClickOpen}
              >
                Asign Vendor
              </button>

              <Dialog
                open={open}
                onClose={handleClose}
                fullWidth={false}
                maxWidth={"md"}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                PaperProps={{
                  style: {
                    top: "0",
                    margin: "0",
                    borderRadius: "30px",
                  },
                }}
              >
                <button
                  style={{
                    position: "absolute",
                    top: "10px",
                    right: "10px",
                    background: "#27851e",
                    border: "none",
                    borderRadius: "50%",
                    cursor: "pointer",
                    padding: "5px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    width: "32px",
                    height: "32px",
                  }}
                  onClick={handleClose}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="feather feather-x"
                    style={{
                      display: "block",
                      width: "100%",
                      height: "100%",
                    }}
                  >
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </button>
                <DialogTitle
                  id="alert-dialog-title"
                  style={{ fontWeight: "700", fontSize: "20px" }}
                >
                  Add Vendor
                </DialogTitle>
                <DialogContent>
                  <div className="row">
                    <div className="col-12 swapBox">
                      <form className="row justify-content-around" onSubmit={createVendor}>

                        <div className="row">
                          <div className="col-4">
                            <label>Acquired By</label>
                          </div>
                          <div className="col-8">
                            <select
                              className="form-select mb-3"
                              aria-label="Assign To Member select"
                              value={AcquiredBy}
                              onChange={(e)=>setAcquiredBy(e.target.value)}
                            >
                              <option value="">Select One</option>
                              {name && name.length > 0 ? (
                                name.map((member) => (
                                  <option key={member.id} value={member.id} className="text-uppercase">
                                    {member.name + " (" + member.empid + ")"}
                                  </option>
                                ))
                              ) : (
                                <option disabled>No members available</option>
                              )}
                            </select>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-4">
                            <label>Vendor Name</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="EX- (WEALTHPAY,RPAY)"
                              className="form-control mb-3"
                              value={VendorNameAdmin}
                              onChange={(e)=>setVendorNameAdmin(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Type</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="EX- (1=payin 10=payout)"
                              className="form-control mb-3"
                              value={Type}
                              onChange={(e)=>setType(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Currency</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="EX- (INR,EUR,USD)"
                              className="form-control mb-3"
                              value={Currency}
                              onChange={(e)=>setCurrency(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Payment Type</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="EX- (BANK TRANSFER,EWALLET(PAYMAYA))"
                              className="form-control mb-3"
                              value={PaymentType}
                              onChange={(e)=>setPaymentType(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Rate</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="EX- (1%)"
                              className="form-control mb-3"
                              value={Rate}
                              onChange={(e)=>setRate(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Minimum</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="EX- (100)"
                              className="form-control mb-3"
                              value={Minimum}
                              onChange={(e)=>setMinimum(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Maximum</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="EX- (1000)"
                              className="form-control mb-3"
                              value={Maximum}
                              onChange={(e)=>setMaximum(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>LiveFrom</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="date"
                              className="form-control mb-3"
                              value={Live}
                              onChange={(e)=>setLive(e.target.value)}
                            />
                          </div>
                        </div>
                        <div>
                          <button
                            className="btn btn me-2"
                            style={{
                              background: "#27851e",
                              color: "#fff",
                              marginLeft: "auto",
                              display: "block",
                              width: "100px",
                            }}
                            type="submit"
                          >
                            Create
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>
      <TableContainer className="tablecontainer2 mt-4">
        <Table
          sx={{ minWidth: 650 }}
          className="table-striped table-hover"
          aria-label="simple table"
        >
          <TableHead>
            <TableRow>
            <TableCell className="tablefont-align">Acquired By</TableCell>
              <TableCell className="tablefont-align">Vendor Name</TableCell>
              <TableCell className="tablefont-align">Status</TableCell>
              <TableCell className="tablefont-align">Type</TableCell>
              <TableCell className="tablefont-align">Currency</TableCell>
              <TableCell className="tablefont-align">Payment Type</TableCell>
              <TableCell className="tablefont-align">Rate(%)</TableCell>
              <TableCell className="tablefont-align">Minimum</TableCell>
              <TableCell className="tablefont-align">Maximum</TableCell>
              <TableCell className="tablefont-align">CreatedOn</TableCell>
              <TableCell className="tablefont-align">LiveFrom</TableCell>
              <TableCell className="tablefont-align">Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {vendor.map((item, index) => (
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                key={index}
              >
                <TableCell align="center" className="text-capitalize">{item.name}</TableCell>
                <TableCell align="center" className="text-capitalize"><b>{item.vendorName}</b></TableCell>
                 <TableCell align="center">
                  <button
                    style={{
                      padding: '6px 7px',
                      borderRadius: '5px',
                      border: 'none',
                      backgroundColor:
                        item.status == 0 ? '#f44336' :
                          item.status == 1 ? '#4caf50': item.status == 2 ? '#ff9800': 
                                '#9e9e9e',
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '12px',
                      fontWeight:"500",
                      width:"78px"
                    }}   onClick={() => updateLeaveStatus(item.status, item.id1)}
                  >
                    {
                      item.status == 0 ? 'NOT LIVE' :
                        item.status == 1 ? 'LIVE' :item.status == 2 ? 'Discontinue': 'Unknown'
                    }
                  </button>


                </TableCell>

                <TableCell align="center">
                  <button
                    style={{
                      padding: '6px 7px',
                      borderRadius: '5px',
                      border: 'none',
                      backgroundColor:
                        item.vendorType == 1 ? '#ff9800' : // Red for Cancelled
                          item.vendorType == 10 ? '#2196f3' : // Blue for Reviewing
                                '#9e9e9e', // Grey for Unknown
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '12px',
                      fontWeight:"500",
                      width:"75px"
                    }}
                  >
                    {
                      item.vendorType == 1 ? 'Payin' :
                        item.vendorType == 10 ? 'Payout' : 'Unknown'
                    }
                  </button>
                </TableCell>
               
                {/* <TableCell align="center">
                  <button
                    style={{
                      padding: '5px 10px',
                      borderRadius: '5px',
                      border: 'none',
                      backgroundColor:
                        item.status == 0 ? '#f44336' : // Red for Cancelled
                          item.status == 1 ? '#4caf50' : // Green for Completed
                            item.status == 2 ? '#ff9800' : // Orange for In-Progress
                              item.status == 3 ? '#2196f3' : // Blue for Reviewing
                                '#9e9e9e', // Grey for Unknown
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '14px',
                    }}
                  >
                    {
                      item.status == 0 ? 'Cancelled' :
                        item.status == 1 ? 'Completed' :
                          item.status == 2 ? 'In-Progress' :
                            item.status == 3 ? 'Reviewing' : 'Unknown'
                    }
                  </button>
                </TableCell> */}

                <TableCell align="center">{item.vendorCurrency}</TableCell>
                <TableCell align="center">{item.paymentType}</TableCell>
                <TableCell align="center">{item.rate}</TableCell>
                <TableCell align="center">{item.minimumReqAmount}</TableCell>
                <TableCell align="center">{item.maximumReqAmount}</TableCell>
                
                <TableCell align="center">{item.createdOn}</TableCell>
                <TableCell align="center">{item.liveFrom}</TableCell>
                <TableCell className="text-end ">
                  <Link
                    className="btn rounded  btn-sm font-sm action-button"
                    style={{ color: 'green' }}
                    to=""
                    data-bs-toggle="dropdown"

                  >
                    <MoreHorizIcon />
                  </Link>
                  <div className="dropdown-menu">
                    {/* <Link className="dropdown-item" to="/">
                        View Full Details
                      </Link> */}
                    <Link className="dropdown-item" to="/">
                      Edit Employee
                    </Link>
                    <Link className="dropdown-item text-danger" onClick={()=>deleteTeam(item.id1)}>
                      Delete
                    </Link>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
     <div>
     <PaginationComp
       setPage={setPage}
       page={page}
       totalPage={totalPage}
       message={message}
     />
   </div>
   </div>
  );
};

export default Vendor;
