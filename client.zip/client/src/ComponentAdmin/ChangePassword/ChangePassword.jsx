import React, { useState } from "react";
import img1 from "./change.avif";
import "./ChangePassword.css";
import axios from "axios";
import { toast } from "react-toastify";
import { Avatar } from "@mui/material";
import eye from '../ChangePassword/Eye.svg'
import eyeIcon from '../ChangePassword/image.png'
import baseUrl from "../../ComponentEmployee/config/baseUrl";

const ChangePassword = () => {
  const [hidePassCurrent, setHidePassCurrent] = useState(true);
  const [hidePassNew, setHidePassNew] = useState(true);
  const [hidePassConfirm, setHidePassConfirm] = useState(true);
  const [oldPassword,setOldPassword]=useState('')
  const [newPassword,setNewPassword]=useState('')
  const [confirmPassword,setConfirmPassword]=useState('')


const auth=localStorage.getItem('admin')

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let formData = new FormData();
      formData.append("oldPassword",oldPassword);
      formData.append("newPassword",newPassword);
      formData.append("confirmPassword",confirmPassword);
      formData.append("token", auth);
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(
        `${baseUrl}/changePasswordAdmin`,
        formData,
        config
      );
      if (result.status === 200) { 
        toast.success(result.data.message, {
          position: "bottom-right",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
       

      } else {
        toast.error(result.data.message, {
          position: "bottom-right",
          autoClose: 1000,  
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  // TogglesetInputData visibility for each password field
  const togglePasswordVisibility = (field) => {
    if (field === "current") {
      setHidePassCurrent(!hidePassCurrent);
    } else if (field === "new") {
      setHidePassNew(!hidePassNew);
    } else if (field === "confirm") {
      setHidePassConfirm(!hidePassConfirm);
    }
  };
  return (
    <div className="container">
      <div className=" row d-flex justify-content-center align-items-center mt-5">
        <div className="col-sm-12 col-md-8 col-lg-5 changepsaaward-content pb-5">
          <form onSubmit={handleSubmit} className=" px-5 " style={{height:"520px"}}>
            
            <div className="d-flex justify-content-center mb-3 mt-2">
              <Avatar style={{height:"80px", width:"80px"}}/>
            </div>
            <p className="text-center">Edit Profile</p>
            <label>Current Password</label>
              <div style={{ position: "relative" }}>
                <input
                  type={hidePassCurrent ? "password" : "text"} // Toggle between password and text
                  placeholder="Current Password"
                  className="form-control mt-2 change-password-input"
                  value={oldPassword}
                  onChange={(e)=>{setOldPassword(e.target.value)}}
                />
                <img
                  src={hidePassCurrent ? eyeIcon : eye} // Change icon based on visibility
                  alt="eye-icon"
                   className="eye-icon"
                  onClick={() => togglePasswordVisibility("current")} // Toggle visibility on click
                />
              </div>

              {/* New Password */}
              <label className="mt-3">New Password</label>
              <div style={{ position: "relative" }}>
                <input
                  type={hidePassNew ? "password" : "text"}
                  placeholder="New Password"
                  className="form-control mt-2 change-password-input"
                  value={newPassword}
                  onChange={(e)=>{setNewPassword(e.target.value)}}
                />
                <img
                  src={hidePassNew ? eyeIcon : eye} 
                  alt="eye-icon"
                   className="eye-icon"
                  onClick={() => togglePasswordVisibility("new")} 
                />
              </div>

              {/* Confirm Password */}
              <label className="mt-3">Confirm Password</label>
              <div style={{ position: "relative" }}>
                <input
                  type={hidePassConfirm ? "password" : "text"} 
                  placeholder="Confirm Password"
                  className="form-control mt-2 change-password-input"
                  value={confirmPassword}
                  onChange={(e)=>{setConfirmPassword(e.target.value)}}
                />
                <img
                  src={hidePassConfirm ? eyeIcon : eye} 
                  alt="eye-icon"
                   className="eye-icon"
                  onClick={() => togglePasswordVisibility("confirm")}
                />
              </div>
           <p className="mb-1">Note: Your password must be 8-20 characters long, contain letters and number.<br/>
           </p>
           <button className="btn  w-100 text-light" style={{borderRadius:"12px",background: "#38d39f",}}>Change Password</button>
          </form>
        </div>
      </div>
    </div>
  );   
};

export default ChangePassword;
