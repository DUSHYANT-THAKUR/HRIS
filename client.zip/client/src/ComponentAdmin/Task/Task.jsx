import React, { useEffect, useState } from "react";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogTitle } from "@mui/material";
import baseUrl from "../../ComponentEmployee/config/baseUrl";
import axios from "axios";
import Search from "../../ComponentEmployee/CommonComponentEmployee/Search/Search";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { toast } from "react-toastify";

const Task = () => {
  const auth = localStorage.getItem("admin");
  const [open, setOpen] = useState(false);
  const [searchItem, setSearchItem] = useState("");
  const [task, setTask] = useState([]);
  const [name, setName] = useState([]);
  const [member, setMember] = useState("");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  // const [date,setDate]=useState('')
  const [status, setStatus] = useState("");
  const [createTask, setCreateTask] = useState([]);
  const fetchData = async () => {
    try {
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };
      let data = {
        searchitem: searchItem,
      };
      let result = await axios.post(`${baseUrl}/fetchEmpName`, {}, config);
      setName(result.data.result);
      console.log(result.data.result);

      let resultTask = await axios.post(`${baseUrl}/fetchEmpTask`, {}, config);
      setTask(resultTask.data.result);
      console.log(resultTask.data.result);
    } catch (error) {
      console.log(error);
    }
  };
  const insertCreateData = async (e) => {
    try {
      e.preventDefault();
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          //  Authorization: `Bearer ${auth}`,
        },
      };
      let data = {
        userId: member,
        subject: subject,
        requestData: description,
        // date: date,
        status: status,
      };
      let resultCreateTask = await axios.post(
        `${baseUrl}/createTask`,
        data,
        config
      );
      console.log(resultCreateTask.data);

      fetchData();
      window.location.reload();
      setOpen(false);
    } catch (error) {
      console.log(error);
    }
  };
  let deleteTaskRequest = async (taskId) => {
    const formData = new FormData();
    formData.append("task_id", taskId);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
        Authorization: `Bearer ${auth}`,
      },
    };

    const result = await axios.post(
      `${baseUrl}/deleteTaskRequest`,
      formData,
      config
    );
    if (result.status == 200) {
      toast.success(result.data.message, {
        position: "bottom-right",
        autoClose: 2000,
      });
      window.location.reload();
    } else {
      toast.error("error", {
        position: "bottom-right",
        autoClose: 1000,
      });
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  return (
    <div className="card mt-4 table-container">
      <header className="table-header p-4">
        <h5 className="card-title" style={{ fontWeight: 600 }}>
          Task Requests
        </h5>
        <div className="row search-container ms-1">
          <div className="col-lg-4 col-md-6 me-auto">
            {/* <div className="row search-container ms-1"> */}
            <div className="col-8">
              <Search serchItem={searchItem} setSearchItem={setSearchItem} />
            </div>
          </div>
          {/* <div className="col-lg-2 col-6 col-md-3 mt-1">
            <select className="form-select p-2">
              <option>Status</option>
              <option>Completed</option>
              <option>In Progress</option>
              <option>Reviewing</option>
              <option>Cancelled</option>
            </select>
          </div> */}
          <div className="col-lg-2 col-6 col-md-3 mt-1">
            <div>
              <button
                style={{
                  background: "#27851e",
                  borderRadius: "30px",
                  color: "#fff",
                  width: "100px",
                  height: "36px",
                  cursor: "pointer",
                  border: "none",
                }}
                onClick={handleClickOpen}
              >
                Assign Task
              </button>

              <Dialog
                open={open}
                onClose={handleClose}
                fullWidth={false}
                maxWidth={"md"}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                PaperProps={{
                  style: {
                    top: "0",
                    margin: "0",
                    borderRadius: "30px",
                  },
                }}
              >
                <button
                  style={{
                    position: "absolute",
                    top: "10px",
                    right: "10px",
                    background: "#27851e",
                    border: "none",
                    borderRadius: "50%",
                    cursor: "pointer",
                    padding: "5px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    width: "32px",
                    height: "32px",
                  }}
                  onClick={handleClose}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="feather feather-x"
                    style={{
                      display: "block",
                      width: "100%",
                      height: "100%",
                    }}
                  >
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </button>
                <DialogTitle
                  id="alert-dialog-title"
                  style={{ fontWeight: "700", fontSize: "20px" }}
                >
                  Add Task
                </DialogTitle>
                <DialogContent>
                  <div className="row">
                    <div className="col-12 swapBox">
                      <form
                        className="row justify-content-around"
                        onSubmit={insertCreateData}
                      >
                        <div className="row">
                          <div className="col-4">
                            <label>Assign To Member</label>
                          </div>
                          <div className="col-8">
                            <select
                              className="form-select mb-3"
                              aria-label="Assign To Member select"
                              value={member}
                              onChange={(e) => {
                                setMember(e.target.value);
                              }}
                            >
                              <option value="">Select One</option>
                              {name && name.length > 0 ? (
                                name.map((member) => (
                                  <option
                                    key={member.id}
                                    value={member.id}
                                    className="text-uppercase"
                                  >
                                    {member.name + " (" + member.empid + ")"}
                                  </option>
                                ))
                              ) : (
                                <option disabled>No members available</option>
                              )}
                            </select>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-4">
                            <label>Task Subject</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="text"
                              placeholder="Task subject"
                              className="form-control mb-3"
                              value={subject}
                              onChange={(e) => {
                                setSubject(e.target.value);
                              }}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Task Description</label>
                          </div>
                          <div className="col-8">
                            <textarea
                              type="text"
                              placeholder="Type here"
                              className="form-control mb-3"
                              value={description}
                              onChange={(e) => {
                                setDescription(e.target.value);
                              }}
                            />
                          </div>
                        </div>
                        {/* <div className="row">
                          <div className="col-4">
                            <label>Priority Level</label>
                          </div>
                          <div className="col-8 mb-3">
                            <select
                              class="form-select"
                              aria-label="Default select example"
                            >
                              <option selected>Pick Your Priority Level</option>
                              <option value="1">HIGH</option>
                              <option value="2">MODERATE</option>
                              <option value="3">LOW</option>
                            </select>
                          </div>
                        </div> */}
                        {/* <div className="row">
                          <div className="col-4">
                            <label>Date</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="date"
                              className="form-control mb-3"
                              value={date}
                              onChange={(e)=>{setDate(e.target.value)}}
                            />
                          </div>
                        </div> */}
                        <div className="row">
                          <div className="col-4">
                            <label>Task Status</label>
                          </div>
                          <div className="col-8">
                            <select
                              class="form-select mb-3"
                              aria-label="Default select example"
                              value={status}
                              onChange={(e) => {
                                setStatus(e.target.value);
                              }}
                            >
                              <option selected>Status of Task</option>
                              <option value="2">In Progress</option>
                              <option value="1">Completed</option>
                              <option value="3">Reviewing</option>
                              <option value="0">Cancelled</option>
                            </select>
                          </div>
                        </div>
                        <div>
                          <button
                            className="btn btn me-2"
                            style={{
                              background: "#27851e",
                              color: "#fff",
                              marginLeft: "auto",
                              display: "block",
                              width: "100px",
                            }}
                            type="submit"
                          >
                            Create
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>
      <TableContainer className="tablecontainer2 mt-4">
        <Table
          sx={{ minWidth: 650 }}
          className="table-striped table-hover"
          aria-label="simple table"
        >
          <TableHead>
            <TableRow>
              <TableCell className="tablefont-align">Task ID</TableCell>
              <TableCell className="tablefont-align">Assigned To</TableCell>
              <TableCell className="tablefont-align">Subject</TableCell>
              <TableCell className="tablefont-align">
                Task Description
              </TableCell>
              <TableCell className="tablefont-align">Status</TableCell>
              <TableCell className="tablefont-align">Start Date</TableCell>
              <TableCell className="tablefont-align">Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {task.map((item, index) => (
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                key={index}
              >
                <TableCell align="center">{item.task_id}</TableCell>
                <TableCell align="center">{item.user_id}</TableCell>
                <TableCell align="center">{item.subject}</TableCell>
                <TableCell align="center">{item.request_data}</TableCell>
                {/* <TableCell align="center">{item.status}</TableCell> */}
                <TableCell align="center">
                  <button
                    style={{
                      padding: "5px 10px",
                      borderRadius: "5px",
                      border: "none",
                      backgroundColor:
                        item.status == 0
                          ? "#f44336" // Red for Cancelled
                          : item.status == 1
                          ? "#4caf50" // Green for Completed
                          : item.status == 2
                          ? "#ff9800" // Orange for In-Progress
                          : item.status == 3
                          ? "#2196f3" // Blue for Reviewing
                          : "#9e9e9e", // Grey for Unknown
                      color: "white",
                      cursor: "pointer",
                      fontSize: "14px",
                    }}
                  >
                    {item.status == 0
                      ? "Cancelled"
                      : item.status == 1
                      ? "Completed"
                      : item.status == 2
                      ? "In-Progress"
                      : item.status == 3
                      ? "Reviewing"
                      : "Unknown"}
                  </button>
                </TableCell>

                <TableCell align="center">{item.created_on}</TableCell>
                <TableCell className="text-end ">
                  <Link
                    className="btn rounded  btn-sm font-sm action-button"
                    style={{ color: "green" }}
                    to=""
                    data-bs-toggle="dropdown"
                  >
                    <MoreHorizIcon />
                  </Link>
                  <div className="dropdown-menu">
                    {/* <Link className="dropdown-item" to="/">
                        View Full Details
                      </Link> */}
                    {/* <Link className="dropdown-item" to="/">
                      Update Status
                    </Link> */}
                    <Link
                      className="dropdown-item text-danger "
                      onClick={() => {
                        deleteTaskRequest(item.task_id);
                      }}
                    >
                      Delete
                    </Link>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default Task;
