// src/ComponentAdmin/AdminRoutes/AdminRouters.js
import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Sidebar from '../AdminSidebar/Sidebar'; // Adjust the path as needed
import AdminLogin from '../Login/AdminLogin';
import Dashboard from '../Dashboard/Dashboard';
// import Calendar from '../AdminCalendar/Calendar';



import Task from '../Task/Task';
import AdminEmployee from '../AdminEmployee/AdminEmployee';
import ChangePassword from '../ChangePassword/ChangePassword';

const AdminRouters = () => {
  const location = useLocation();
  console.log("my path",location.pathname)
  
  return (
    <div>
     {/* {location.pathname !== '/' && <Sidebar />} */}
      <div >
        {/* <Routes> */}
       <AdminLogin/>
        {/* </Routes> */}
      </div>
      </div>
  );
};

export default AdminRouters;
