import React, { useEffect, useState } from "react";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import "bootstrap/dist/css/bootstrap.min.css";
import Paginations from "../CommonComponentEmployee/Pagination/Pagination";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import * as XLSX from "xlsx";
import "../Employee/Employee.css"
import Search from "../CommonComponentEmployee/Search/Search";
function VendorIntegation() {
    const [team, setTeam] = useState([]);
    const [searchItem, setSearchItem] = useState("");
    const [page, setPage] = useState(1);
    const [totalPage, setTotalPage] = useState(0);
    const [message, setMessage] = useState("");
    const auth = localStorage.getItem("user");
    const fetchTeam = async () => {
        try {
            let formData = new FormData();
            formData.append("searchItem", searchItem);
            formData.append("page", page);
            const config = {
                headers: {
                    "Content-type": "application/json",
                    Accept: "application/json",
                    Authorization: `Bearer ${auth}`,
                },
            };
            let result = await axios.post(`${baseUrl}/defaultVendorList`, formData, config);
            setTeam(result.data.result);
            setTotalPage(result.data.totalPage)
            setMessage(result.data.message)
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };
    const downloadExl = async () => {
        try {
            const auth = localStorage.getItem("user");
            let formData = new FormData();
            formData.append("searchitem", searchItem);
            const config = {
                headers: {
                    "content-type": "multipart/form-data",
                    Authorization: `Bearer ${auth}`,
                },
            };
            const data = await axios.post(`${baseUrl}/defaultVendorList`, formData, config);
            const workSheet = XLSX.utils.json_to_sheet(data.data.result);
            const workBook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workBook, workSheet, `VENDOR_LIST_${Date.now()}`);
            XLSX.writeFile(workBook, `VENDOR_LIST_${Date.now()}.xlsx`);
        } catch (err) {
            console.error("Error while downloading the file:", err);
        }
    };
    useEffect(() => {
        fetchTeam();
    }, [page, searchItem]);
    return (
        <div className="employee-content-container mt-4 me-4">
            <div className="row">
                <div className="col-12 ms-2 ms-md-0"><h5 style={{ fontWeight: '700' }}>Vendor Integration</h5></div>
            </div>
            <div className="row mt-2">
                <div className="row search-container ms-1">
                    <div className="col-6 col-md-3">
                        <Search serchItem={searchItem} setSearchItem={setSearchItem} />
                    </div>
                    <div className="col-6 col-md-9 text-end">
                        <button className="btn btn-primary ms-2" onClick={downloadExl}>Download</button>
                    </div>
                </div>
            </div>
            <div className="row">
                <TableContainer className="tablecontainer2 mt-4">
                    <Table sx={{ minWidth: 650 }} className="table-striped table-hover" aria-label="simple table">
                        <TableHead>
                            <TableRow >
                                <TableCell className="tablefont-align">Vendor Name</TableCell>
                                <TableCell className="tablefont-align">Status</TableCell>
                                {/* <TableCell className="tablefont-align">Gender</TableCell> */}
                                <TableCell className="tablefont-align">Vendor Type</TableCell>
                                <TableCell className="tablefont-align">Currency</TableCell>
                                <TableCell className="tablefont-align">Payment Type</TableCell>
                                <TableCell className="tablefont-align">Rate</TableCell>
                                <TableCell className="tablefont-align">Min. Amount</TableCell>
                                <TableCell className="tablefont-align">Max. Amount</TableCell>
                                <TableCell className="tablefont-align">Live From</TableCell>
                                <TableCell className="tablefont-align">Created On</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                        {team.map((item, index) => (
                                <TableRow
                                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                                    key={index}
                                >
                                    <TableCell align="center">{item.vendorName}</TableCell>
                                    <TableCell align="center">{item.status==1?(<button className="report-btn-live">Live</button>): item.status==2 ? (<button className="report-btn-discontinue">Discontinue</button>) : (<button className="report-btn-notLive">Not Live</button>)}</TableCell>
                                    <TableCell align="center">{item.vendorType==1?"Deposit":"Payout"}</TableCell>
                                    <TableCell align="center">{item.vendorCurrency}</TableCell>
                                    <TableCell align="center">{item.paymentType}</TableCell>
                                    <TableCell align="center">{item.rate+'%'}</TableCell>
                                    <TableCell align="center">{item.minimumReqAmount}</TableCell>
                                    <TableCell align="center">{item.maximumReqAmount}</TableCell>
                                    <TableCell align="center">{item.liveFrom}</TableCell>
                                    <TableCell align="center">{item.createdOn}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
            <div className="row">
                <Paginations page={page} setPage={setPage} totalPage={totalPage} message={message} />
            </div>
        </div>
    );
}
export default VendorIntegation;