import React, { useState, useEffect } from "react";
import "./Attendence.css";
import axios from "axios";
import baseUrl from "../config/baseUrl";

const Attendance = () => {
  const auth = localStorage.getItem("user");
  const months = [
    "January", "February", "March", "April", "May", "June", 
    "July", "August", "September", "October", "November", "December"
  ];

  const today = new Date();
  const currentDay = today.getDate();
  const Month = today.getMonth();
  const Year = today.getFullYear();
  const [selectedDate, setSelectedDate] = useState(currentDay);
  const [currentMonthIndex, setCurrentMonthIndex] = useState(Month);
  const [currentYear, setCurrentYear] = useState(Year);
  const [attendanceData, setAttendanceData] = useState([]);

  const slackAttendanceByEmployee = async () => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };

      let result = await axios.post(`${baseUrl}/fetchAttendance`, {}, config);
      setAttendanceData(result.data.result);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    slackAttendanceByEmployee();
  }, []);

  const daysInMonth = (monthIndex, year) => {
    return new Date(year, monthIndex + 1, 0).getDate();
  };

  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const currentMonth = months[currentMonthIndex];
  const totalDays = daysInMonth(currentMonthIndex, currentYear);

  const handleDateClick = (day) => {
    setSelectedDate(day);
  };

  const handleNextDay = () => {
    if (currentMonthIndex === 11) {
      setCurrentMonthIndex(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonthIndex(currentMonthIndex + 1);
    }
  };

  const handlePrevDay = () => {
    if (currentMonthIndex === 0) {
      setCurrentMonthIndex(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonthIndex(currentMonthIndex - 1);
    }
  };

  const handleReset = () => {
    setSelectedDate(currentDay);
    setCurrentMonthIndex(Month);
    setCurrentYear(Year);
  };

  const findAttendanceForDay = (day) => {
    const formattedDate = `${currentYear}-${(currentMonthIndex + 1)
      .toString()
      .padStart(2, "0")}-${day.toString().padStart(2, "0")}`;

    // Use `created_on` from API response to match the date
    const attendanceForDay = attendanceData.find(
      (record) => record.created_on === formattedDate
    );

    return {
      inTime: attendanceForDay ? attendanceForDay.log_in : null,
      outTime: attendanceForDay ? attendanceForDay.log_out : null,
    };
  };

  const generateCalendarDays = () => {
    const calendarDays = [];
    let firstDay = new Date(`${currentMonth}, ${currentYear}`).getDay();

    for (let i = 0; i < firstDay; i++) {
      calendarDays.push(<td key={`empty-${i}`} className="attendance-data"></td>);
    }

    for (let day = 1; day <= totalDays; day++) {
      const { inTime, outTime } = findAttendanceForDay(day);

      calendarDays.push(
        <td key={day} className={day === selectedDate ? "selected" : ""} onClick={() => handleDateClick(day)}>
          <div>
            <span>{day}</span>
            <div>
              {inTime && <span className="fw-bold">In: {inTime}</span>}
              <br />
              {outTime && <span className="fw-bold">Out: {outTime}</span>}
            </div>
          </div>
        </td>
      );
    }

    while (calendarDays.length % 7 !== 0) {
      calendarDays.push(<td key={`empty-${calendarDays.length}`}></td>);
    }

    return calendarDays;
  };

  return (
    <div className="container-fluid d-flex justify-content-center align-items-center">
      <div className="attendance-calendar shadow">
        <div className="attendance-calendar-left text-white p-3 d-flex flex-column justify-content-center align-items-center">
          <div className="d-flex justify-content-between align-items-center">
            <h1 className="bold-date mb-3 text text-warning">{selectedDate}</h1>
          </div>
          <p  className = 'fw-bold' style={{color:"white",alignSelf:"center"}}>
            <i className="fa-solid fa-chevron-left pe-2 text text-warning" onClick={handlePrevDay} style={{cursor:"pointer"}}></i>
            <span className="text text-warning" style={{fontSize:"16px"}}>{currentMonth.toUpperCase()}- {currentYear}</span>
            <i className="fa-solid fa-chevron-right ps-2 text text-warning" style={{cursor:"pointer"}} onClick={handleNextDay}></i>
          </p>
          <button onClick={handleReset} className="btn btn-sm border border-2 text-white reset-btn" style={{ fontWeight: "600" }}>
            RESET
          </button>
        </div>

        <div className="attendance-calendar-right p-3">
          <table className="table outer-table">
            <thead>
              <tr>
                {daysOfWeek.map((day) => (
                  <th key={day}>{day}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {generateCalendarDays().map((day, index) =>
                index % 7 === 0 ? (
                  <tr key={index}>
                    {generateCalendarDays().slice(index, index + 7)}
                  </tr>
                ) : null
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Attendance;
