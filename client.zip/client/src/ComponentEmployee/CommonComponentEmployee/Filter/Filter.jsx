import React, { useState } from "react";
import "./Filter.css"
import FilterListIcon from '@mui/icons-material/FilterList';
import { Menu } from "@mui/material";
const Filter = ({ setTo, setFrom, setDate, setThisMonth }) => {

    const [anchorEl, setAnchorEl] =useState(null);
    const [show, setShow] = React.useState(false);
    const [todate, SetToDate] = useState("");
    const [fromdate, SetFromDate] = useState("");
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        event.preventDefault();
      setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };
    let todayFilter = () => {
        let todayDate = new Date();
        let todayDay = todayDate.getDate();
        let todayMonth = todayDate.getMonth() + 1;
        let todayYear = todayDate.getFullYear();
        let todayFullDate = todayYear + "-" + (todayMonth < 10 ? "0" + todayMonth : todayMonth) + "-" + (todayDay < 10 ? "0" + todayDay : todayDay);
        setDate(todayFullDate)
        handleClose();
    }
    let yesterdayFilter = () => {
        let todayDate = new Date();
        let yesterdayDay = todayDate.getDate() - 1;
        let yesterdayMonth = todayDate.getMonth() + 1;
        let yesterdayYear = todayDate.getFullYear();
        let yesterdayFullDate = yesterdayYear + "-" + (yesterdayMonth < 10 ? "0" + yesterdayMonth : yesterdayMonth) + "-" + (yesterdayDay < 10 ? "0" + yesterdayDay : yesterdayDay);
        setDate(yesterdayFullDate)
        handleClose();
    }
    let setToFromDate = (e) => {
        e.preventDefault();
        setTo(todate);
        setFrom(fromdate);
        handleClose();
    }
    return (
        <>
            <div className="date-filter">
                <button
                    className="filterdate"
                    aria-controls={open ? "basic-menu" : undefined}
                    aria-haspopup="true"
                    aria-expanded={open ? "true" : undefined}
                    onClick={handleClick}
                >
                    {/* <img
                        src="https://www.bankconnect.online/assets/merchants/img/calender.svg"
                        alt=""
                        className="mx-2"
                        style={{height:"17px"}}
                    /> */}
                    <FilterListIcon />
                    <span>Filter Date</span>
                    <img
                        src="https://www.bankconnect.online/assets/merchants/img/cev-down.svg"
                        alt=""
                        className="mx-2"
                    />
                </button>
                <Menu
                    id="basic-menu"
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleClose}
                    MenuListProps={{
                        "aria-labelledby": "basic-button",
                    }}
                    className="my-3"
                >
                    <div className="row m-4">
                        <div className="col-12 mt-2 text-center col-md-4 mt-md-0 text-md-start mb-sm-1">
                            <button className="buttondate" onClick={yesterdayFilter}>
                                Yesterday
                            </button>
                        </div>
                        <div className="col-12 mt-2 text-center col-md-4 mt-md-0 text-md-start mb-sm-1">
                            <button className="buttondate" onClick={todayFilter}>
                                Today
                            </button>
                        </div>
                        <div className="col-12 mt-2 text-center col-md-4 mt-md-0 text-md-start mb-sm-1">
                            <button className="buttondate" onClick={() => setShow(!show)}>
                                Customize
                            </button>
                        </div>
                    </div>
                    {show ? (
                        <form className="row mx-2 align-items-center pt-4"
                            style={{ boxShadow: "0 4px 8px grey", }}>
                            <div className="col-12 d-md-flex justify-content-center ">
                                <input
                                    type="date"
                                    className="dateinput col-4 "
                                    // value={todate}
                                    onChange={(e) => SetFromDate(e.target.value)}
                                />
                                <div className="col-2 d-flex justify-content-center mt-2">
                                    <b>To</b>
                                </div>
                                <input
                                    type="date"
                                    className="dateinput col-4"
                                    // value={fromdate}
                                    onChange={(e) => SetToDate(e.target.value)}
                                />
                            </div>
                            <div className="d-flex justify-content-center">
                                <button className="lastbottonfilter mt-3" onClick={(e)=>setToFromDate(e)}>
                                    Filter
                                </button>
                            </div>
                        </form>
                    ) : (
                        ""
                    )}
                </Menu>
            </div>
        </>
    )
}
export default Filter;














// <div className="date-filter">
// <Dropdown>
//     <Dropdown.Toggle className="date-toggle bg-primary border border-0">
//         <FilterListIcon className="me-2" />
//         {selectedOption}
//     </Dropdown.Toggle>
//     <Dropdown.Menu className="date-dropdown">
//         <Dropdown.Item
//             onClick={() => { handleDropdownSelect("Today"); todayFilter() }
//             }
//             className="border border-1 mb-2 bg-primary text-light mt-4"
//         >
//             Today
//         </Dropdown.Item>
//         <Dropdown.Item
//             onClick={() => { handleDropdownSelect("Yesterday"); yesterdayFilter() }}
//             className="border border-1 mb-2 bg-primary text-light"
//         >
//             Yesterday
//         </Dropdown.Item>
//         <Dropdown.Item
//             onClick={() => { handleDropdownSelect("This Month"); thisMonthFilter() }}
//             className="border border-1 mb-2 bg-primary text-light"
//         >
//             This Month
//         </Dropdown.Item>
//         <div className="customize-date">
//             <div className="date-range mt-2">
//                 <div className="date-input-group ">
//                     <label>From</label>
//                     <input
//                         type="date"
//                         name="from"
//                         //   value={dateRange.from}
//                         onChange={(e) => { setFromDate(e.target.value) }}
//                     />
//                 </div>
//                 <div className="date-input-group">
//                     <label>To</label>
//                     <input
//                         type="date"
//                         name="to"
//                         //   value={dateRange.to}
//                         onChange={(e) => setToDate(e.target.value)}
//                     />
//                 </div>
//             </div>
//             <div className="d-flex justify-content-center">
//                 <Dropdown.Item
//                     className="border border-1 mb-2 text-light bg-primary w-50" onClick={setToFromDate()}
//                 >
//                     filter
//                 </Dropdown.Item>
//             </div>
//         </div>
//     </Dropdown.Menu>
// </Dropdown>
// </div>