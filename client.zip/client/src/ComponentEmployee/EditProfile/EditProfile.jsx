import * as React from "react";
import EmailIcon from "@mui/icons-material/Email";
import { useStateContext } from "../../context/ContextProvider";
import "../EditProfile/EditProfile.css";
import slack from "./images/slack.png";
import jira from "./images/jira.png";
import skype from "./images/skype.png";
import { useState,useEffect } from "react";
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import baseUrl from "../config/baseUrl";
import axios from "axios";
import { toast } from "react-toastify";
const ProfileContent = ({jobTitle}) => {
  const {profileImage} = useStateContext();
  return (
    <>
      <div className="d-flex justify-content-center mt-5">
        <img
          src={`${baseUrl}/${profileImage}`}
          width={70}
          alt="Avatar"
          className="rounded-circle mt-2"
        />
      </div>
      <div className="mt-4 text-secondary">
        <h5 style={{ fontWeight: 600 }}>{localStorage.getItem('userName')}</h5>
        <p style={{ fontSize: "13px",textTransform:"capitalize" }}>{jobTitle}</p>
        <i class="fa-solid fa-pen-to-square fs-5"></i>
      </div>
      <div className="d-flex py-5 px-3 edit-profile-social-media-icon">
        <a
          href="https://mail.google.com/"
          target="_blank"
          rel="noopener noreferrer"
          title="Email"
        >
          <EmailIcon className="text-primary me-2" />
        </a>
        <a
          href="https://app.slack.com/client"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img
            src={slack}
            style={{ height: "25px" }}
            className="me-2"
            title="Slack"
          />
        </a>
        <a
          href="https://ubankconnect.atlassian.net/jira/your-work"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img
            src={jira}
            style={{ height: "25px" }}
            className="me-2"
            title="Jira"
          />
        </a>
        <a
          href="https://www.skype.com"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img
            src={skype}
            style={{ height: "25px" }}
            className="me-2"
            title="Skype"
          />
        </a>
      </div>
    </>
  );
};
const BasicDetails = ({ setActiveTab, activeTab }) => {
  const [fullName, setFullname] = useState("");
  const [gender, setGender] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [empid, setEmpid] = useState("");
  const [team, setTeam] = useState("");
  const [dob, setDob] = useState("");
  const [doj, setDoj] = useState("");
  const [jobTitle,setJobTitle] = useState("");
  const auth = localStorage.getItem("user");

  const handleSubmit = async (e, tab) => {
    try {
      e.preventDefault();
      const formData = new FormData();

      formData.append("tab", tab);
      formData.append("name", fullName);
      formData.append("gender", gender);
      formData.append("email", email);
      formData.append("phone", phone);
      formData.append("empid", empid);
      formData.append("team", team);
      formData.append("dob", dob);
      formData.append("doj", doj);

      const config = {
        headers: {
          "Content-type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };

      const response = await axios.post(
        `${baseUrl}/jsonfile`,
        formData,
        config
      );

      if (response.status == 200) {
        setActiveTab(activeTab + 1);
        toast.success(<span>updated Successfully</span>, {
          position: "bottom-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: false,
          pauseOnHover: false,
          draggable: false,
          progress: undefined,
          closeButton: false,
        });
      } else {
        toast.error(<span>error</span>, {
          position: "bottom-right",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };
  useEffect(() => {
    const fetchdata = async () => {
      const config = {
        headers: {
          "Content-type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      const response = await axios.post(`${baseUrl}/fetchdata`,{}, config);
      setFullname(response.data.result[0].name);
      setGender(response.data.result[0].gender);
      setEmail(response.data.result[0].email);
      setPhone(response.data.result[0].phone);
      setEmpid(response.data.result[0].empid);
      setTeam(response.data.result[0].team);
      setDob(response.data.result[0].dob);
      setDoj(response.data.result[0].doj);
      setJobTitle(response.data.result[0].team)
    };
    fetchdata();
  }, []);

  return (
    <>
      <div className="row ps-0 edit-info" style={{ minHeight: "63vh" }}>
        <div
          className="col-3 text-center"
          style={{
            backgroundColor: "rgb(225, 249, 249)",
            padding: "10px",
          }}
        >
          <ProfileContent jobTitle  ={jobTitle}/>
        </div>
        <div className="col-9">
          <div className="row p-3">
            <div className="col-12 mt-1 bg-primary p-2">
              <h6
                className="mb-1 text-center text-light"
                style={{ fontWeight: 600 }}
              >
                Basic Details
              </h6>
            </div>
          </div>
          <div className="row px-3 mt-2">
            <div className="col-md-6 ">
              <label>Full Name</label>
              <br />
              <input
                type="text"
                name="fullname"
                className="mt-2 form-control"
                defaultValue={fullName}
                onChange={(e) => {
                  setFullname(e.target.value);
                }}
              />
            </div>
            <div className="col-md-6">
              <label>Gender</label>
              <br />
              <input
                type="text"
                name="text"
                className="mt-2 form-control"
                 defaultValue={gender}
                onChange={(e) => {
                  setGender(e.target.value);
                }}
              />
            </div>
          </div>
          <div className="row px-3 mt-2">
            <div className="col-md-6 mt-2">
              <label>Email</label>
              <br />
              <input
                type="email"
                className="mt-2 form-control"
                defaultValue={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
              />
            </div>
            <div className="col-md-6 mt-2">
              <label>Phone</label>
              <br />
              <input
                type="text"
                className="border-none mt-2 form-control"
                defaultValue={phone}
                onChange={(e) => {
                  setPhone(e.target.value);
                }}
              />
            </div>
          </div>
          <div className="row px-3 mt-2">
            <div className="col-md-6 mt-2">
              <label>Employee Id</label>
              <br />
              <input
                type="text"
                className="mt-2 form-control"
                defaultValue={empid}
                onChange={(e) => {
                  setEmpid(e.target.value);
                }}
                disabled
              />
            </div>
            <div className="col-md-6 mt-2">
              <label>Job Title</label>
              <br />
              <input
                type="text"
                className="border-none mt-2 form-control"
                defaultValue={team}
                onChange={(e) => {
                  setTeam(e.target.value);
                }}
                disabled
              />
            </div>
          </div>
          <div className="row px-3 mt-2">
            <div className="col-md-6 mt-2">
              <label>DOB</label>
              <br />
              <input
                type="text"
                className="mt-2 form-control"
                defaultValue={dob}
                onChange={(e) => {
                  setDob(e.target.value);
                }}
              />
            </div>
            <div className="col-md-6 mt-2">
              <label>DOJ</label>
              <br />
              <input
                type="text"
                className="border-none mt-2 form-control"
                defaultValue={doj}
                onChange={(e) => {
                  setDoj(e.target.value);
                }}
                disabled
              />
            </div>
          </div>
          <div className="text-end mt-4 me-3 text-center pb-3">
            <button
              className="btn btn-primary save-btn"
              onClick={(e) => handleSubmit(e, 1)}
            >
              Save & Next
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
const Download = () => {
    const downloadFile = (data) => {
      const fileUrl = `${process.env.PUBLIC_URL}/${data}.pdf`;
      const link = document.createElement("a");
      link.href = fileUrl;
      link.download = "commissionStructure2024.pdf";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
  return (
    <>
      <div className="row ps-0 edit-info" style={{ minHeight: "63vh" }}>
        <div
          className="col-3 text-center"
          style={{
            backgroundColor: "rgb(225, 249, 249)",
            padding: "10px",
          }}
        >
          <ProfileContent />
        </div>
        <div className="col-9">
          <div className="row p-3">
            <div className="col-12 mt-1 bg-primary p-2">
              <h6
                className="mb-1 text-center text-light"
                style={{ fontWeight: 600 }}
              >
                Download
              </h6>
            </div>
          </div>
          <div className="row px-3 mt-2">
            <div className="col-md-6 ">
              <label>Company Info</label>
              <br />
              <button
                className="btn btn-primary mt-3"
                onClick={() => window.open('https://ubankconnect.com/', '_blank')}
              >
                Company Info
              </button>
            </div>
            <div className="col-md-6 ">
              <label>Commission Info</label>
              <br />
              <button
                className="btn btn-primary mt-3"
                onClick={() => downloadFile("commissionStructure2024")}
              >
                <FileDownloadIcon /> Download File
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
const ApiCredential = ({ setActiveTab, activeTab }) => {
  const [file, setFile] = useState(null);
  const [SlackMemberID, setSlackMemberID] = useState("");
  const [SlackProfileURL, setSlackProfileURL] = useState("");
  const [googleCredentials, setGoogleCredentials] = useState(null);
  const [GoogleCalenderID, setGoogleCalenderID] = useState("");
  const auth = localStorage.getItem("user");

  const handleSubmit = async (e, tab) => {
    try {
      e.preventDefault();
      const formData = new FormData();
      formData.append("tab", tab);
      formData.append("slack_uid", SlackMemberID);
      formData.append("slack_profile", SlackProfileURL);
      formData.append("google_calender_id", GoogleCalenderID);
      formData.append("userJson", file);
      const config = {
        headers: {
          "Content-type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };

      const response = await axios.post(
        `${baseUrl}/jsonfile`,
        formData,
        config
      );
      if (response.status == 200) {
        setActiveTab(activeTab + 1);
        toast.success(<span>updated Successfully</span>, {
          position: "bottom-right",
          autoClose: 2000,
          hideProgressBar: false,
          closeOnClick: false,
          pauseOnHover: false,
          draggable: false,
          progress: undefined,
          closeButton: false,
        });
      } else {
        toast.error(<span>error</span>, {
          position: "bottom-right",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };

  useEffect(() => {
    const fetchdata = async () => {
      const config = {
        headers: {
          "Content-type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      const response = await axios.post(`${baseUrl}/fetchdata`, {}, config);
      setSlackMemberID(response.data.result[0].slack_uid);
      setSlackProfileURL(response.data.result[0].slack_profile);
      setGoogleCalenderID(response.data.result[0].google_calender_id);
    };
    fetchdata();
  }, []);
  return (
    <>
      <div className="row ps-0 edit-info" style={{ minHeight: "63vh" }}>
        <div
          className="col-3 text-center"
          style={{
            backgroundColor: "rgb(225, 249, 249)",
            padding: "10px",
          }}
        >
          <ProfileContent />
        </div>
        <div className="col-9">
          <div className="row p-3">
            <div className="col-12 mt-1 bg-primary p-2">
              <h6
                className="mb-1 text-center text-light"
                style={{ fontWeight: 600 }}
              >
                API Credential Details
              </h6>
            </div>
          </div>
          <div className="row px-3 mt-2">
            <div className="col-md-6 ">
              <label>Slack Member ID</label>
              <br />
              <input
                type="id"
                name="id"
                className="mt-2 form-control"
                value={SlackMemberID}
                onChange={(e) => setSlackMemberID(e.target.value)}
              />
            </div>
            <div className="col-md-6">
              <label>Slack Profile URL</label>
              <br />
              <input
                type="url"
                name="url"
                className="mt-2 form-control"
                value={SlackProfileURL}
                onChange={(e) => setSlackProfileURL(e.target.value)}
              />
            </div>
          </div>
          <div className="row px-3 mt-2">
            <div className="col-md-6 mt-2">
              <label htmlFor="file-upload" className="form-label">
                Google Credentials
              </label>
              <div className="custom-file">
                <input
                  type="file"
                  id="file-upload"
                  className="d-none" // hide the default file input
                  name="userJson"
                  accept="application/json"
                  onChange={(e) => setFile(e.target.files[0])}
                />
                <label
                  htmlFor="file-upload"
                  className="btn btn-outline-secondary w-100"
                >
                  {file ? file.name : "Choose file"}
                </label>
              </div>
            </div>
            <div className="col-md-6 mt-2">
              <label>Google Calender ID</label>
              <br />
              <input
                type="text"
                className="border-none mt-2 form-control"
                value={GoogleCalenderID}
                onChange={(e) => setGoogleCalenderID(e.target.value)}
              />
            </div>
          </div>
          <div className="text-end mt-4 me-3 text-center">
            <button
              className="btn btn-primary save-btn"
              onClick={(e) => handleSubmit(e, 2)}
            >
              Save & Next
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
function VerticalTabs() {
  const [activeTab, setActiveTab] = useState(0);
  const handleTabChange = (index) => {
    setActiveTab(index);
  };
  return (
    <div
      className="container-fluid mt-2 border border-1 p-5 edit-profile-container"
      style={{
        boxShadow: "0px 6px 20px rgba(0, 0, 0, 0.15)",
      }}
    >
      <div className="row">
        <div className="col-lg-4 mt-5 vertical-tab ">
          <div className="step-buttons" style={{ cursor: "pointer" }}>
            <div
              className={`step-button ${activeTab === 0 ? "active" : ""}`}
              onClick={() => handleTabChange(0)}
            >
              <div className="step-number">1</div>
              <div className="step-content">
                <h5>Personal Information</h5>
                <p>Personal Information Details</p>
              </div>
            </div>
            <div
              className={`step-button ${activeTab === 1 ? "active" : ""}`}
              onClick={() => handleTabChange(1)}
            >
              <div className="step-number">2</div>
              <div className="step-content">
                <h5>API Credentials</h5>
                <p>API Credentials Details</p>
              </div>
            </div>
            <div
              className={`step-button ${activeTab === 2 ? "active" : ""}`}
              onClick={() => handleTabChange(2)}
            >
              <div className="step-number">5</div>
              <div className="step-content">
                <h5>Download</h5>
                <p>Download Details</p>
              </div>
            </div>
          </div>
        </div>
        <div
          className="form-content mt-5 mb-3 col-lg-8 "
          style={{
            backgroundColor: "#fff",
            borderRadius: "8px",
            boxShadow: "0px 6px 20px rgba(0, 0, 0, 0.15)",
            overflow: "hidden",
            width: "60%", // Conditional width based on activeTab
            margin: "auto",
            border: "1px solid #e0e0e0",
          }}
        >
          {/* Tab Panels */}
          <div>
            {activeTab === 0 && <BasicDetails setActiveTab={setActiveTab} activeTab={activeTab} />}
            {activeTab === 1 && <ApiCredential setActiveTab={setActiveTab} activeTab={activeTab}/>}
            {activeTab === 2 && <Download />}
          </div>
        </div>
      </div>
    </div>
  );
};
export default VerticalTabs;
