import React, { useEffect, useState } from "react";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogTitle } from "@mui/material";
import baseUrl from "../config/baseUrl";
import axios from "axios";
import Search from "../CommonComponentEmployee/Search/Search";
import PaginationComp from "../CommonComponentEmployee/Pagination/Pagination"
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

const Leave = () => {
  const auth = localStorage.getItem("user");
  const [open, setOpen] = useState(false);
  const [searchItem, setSearchItem] = useState("");
  const [data, setData] = useState([])
  const [message, setMessage] = useState("");
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [from_date,setfrom_date]=useState('')
  const [to_date,setto_date]=useState('')
  const [Reason,setReason]=useState('')

  const fetchData = async () => {
    try {
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          Authorization: `Bearer ${auth}`,
        },
      };
      let data = {
        searchItem: searchItem,
        page:page
      };
     
      let resultTask = await axios.post(`${baseUrl}/fetchLeave`,data, config);
        setData(resultTask.data.result)
      setMessage(resultTask.data.message);
      setTotalPage(Number(resultTask.data.totalPage));

      console.log(resultTask.data.result)
    } catch (error) {
      console.log(error);
    }
  }
  const create=async(e)=>{
   e.preventDefault()

   try {
    const config = {
      headers: {
        "content-type": "multipart/form-data",
        Authorization: `Bearer ${auth}`,
      },
    };
    let data = {
      from_date: from_date,
      to_date:to_date,
      Reason:Reason
    };
   
    let result = await axios.post(`${baseUrl}/createLeave`,data, config);
    fetchData()
    window.location.reload()
    console.log(result.data.result)
  } catch (error) {
    console.log(error);
  }

  }

  useEffect(() => { 
    fetchData()
  }, [searchItem]);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  return (
    <div>
    <div className="card mt-4 table-container">
      <header className="table-header p-4">
        <h5 className="card-title" style={{ fontWeight: 600 }}>
          Task Requests
        </h5>
        <div className="row search-container">
          <div className="col-lg-5 col-md-6 me-auto">
            {/* <div className="row search-container ms-1"> */}
            <div className="col-5">
              <Search serchItem={searchItem} setSearchItem={setSearchItem} />
            </div>
          </div>
          <div className="col-lg-2 col-6 col-md-3 mt-1">
            <div>
              <button
                style={{
                  background: "#27851e",
                  borderRadius: "30px",
                  color: "#fff",
                  width: "100px",
                  height: "36px",
                  cursor: "pointer",
                  border: "none",
                }}
                onClick={handleClickOpen}
              >
              Request
              </button>

              <Dialog
                open={open}
                onClose={handleClose}
                fullWidth={false}
                maxWidth={"md"}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                PaperProps={{
                  style: {
                    top: "0",
                    margin: "0",
                    borderRadius: "30px",
                  },
                }}
              >
                <button
                  style={{
                    position: "absolute",
                    top: "10px",
                    right: "10px",
                    background: "#27851e",
                    border: "none",
                    borderRadius: "50%",
                    cursor: "pointer",
                    padding: "5px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    width: "32px",
                    height: "32px",
                  }}
                  onClick={handleClose}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="feather feather-x"
                    style={{
                      display: "block",
                      width: "100%",
                      height: "100%",
                    }}
                  >
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </button>
                <DialogTitle
                  id="alert-dialog-title"
                  style={{ fontWeight: "700", fontSize: "20px" }}
                >
                  Add Leave
                </DialogTitle>
                <DialogContent>
                  <div className="row">
                    <div className="col-12 swapBox">
                      <form className="row justify-content-around" onSubmit={create}>

                       

                        <div className="row">
                          <div className="col-4">
                            <label>FromDate</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="date"
                              className="form-control mb-3"
                              value={from_date}
                              onChange={(e)=>{setfrom_date(e.target.value)}}
                            />
                          </div>
                        </div>
                        
                       
                        <div className="row">
                          <div className="col-4">
                            <label>ToDate</label>
                          </div>
                          <div className="col-8">
                            <input
                              type="date"
                              className="form-control mb-3"
                              value={to_date}
                              onChange={(e)=>{setto_date(e.target.value)}}
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-4">
                            <label>Reason</label>
                          </div>
                          <div className="col-8">
                            <textarea
                              type="text"
                              placeholder="Type here"
                              className="form-control mb-3"
                              value={Reason}
                              onChange={(e)=>{setReason(e.target.value)}}
                            />
                          </div>
                        </div>
                       
                        <div>
                          <button
                            className="btn btn me-2"
                            style={{
                              background: "#27851e",
                              color: "#fff",
                              marginLeft: "auto",
                              display: "block",
                              width: "100px",
                            }}
                            type="submit"
                          >
                            Create
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>
      <TableContainer className="tablecontainer2 mt-4">
        <Table
          sx={{ minWidth: 650 }}
          className="table-striped table-hover"
          aria-label="simple table"
        >
          <TableHead>
            <TableRow>
              <TableCell className="tablefont-align">Requested ID</TableCell>
              <TableCell className="tablefont-align">Employee Id</TableCell>
              <TableCell className="tablefont-align">Name</TableCell>
              <TableCell className="tablefont-align">FromDate</TableCell>
              <TableCell className="tablefont-align">ToDate</TableCell>
              <TableCell className="tablefont-align">Reason</TableCell>
              <TableCell className="tablefont-align">Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
                {data.length > 0 ? (
                  data.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="text-center">{item.requested_Id}</TableCell>
                      <TableCell className="text-center">{item.empid}</TableCell>
                      <TableCell className="text-center">
                        <b className="text-capitalize text-center">{item.name}</b>
                      </TableCell>
                      <TableCell className="text-center">{item.from_date}</TableCell>
                      <TableCell className="text-center">{item.to_date}</TableCell>
                      <TableCell className="text-center" style={{ maxWidth: '200px', whiteSpace: 'normal', wordWrap: 'break-word' }}>
                        {item.Reason}
                      </TableCell>
                     
                        <TableCell className="text-center" >
                          <button 
                            className={`btn
      ${item.status === 0 ? "btn-danger " :
                                item.status === 1 ? "btn-success " :
                                  "btn-warning "}`}
                            aria-label={item.status === 0 ? "Decline" : item.status === 1 ? "Approved" : "Pending"}
                            
                          >
                            {item.status === 0 ? "Decline" : item.status === 1 ? "Approved" : "Pending"}
                          </button>
                        </TableCell>

                      
                    </TableRow>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No tasks found.
                    </td>
                  </tr>
                )}
              </TableBody>
        </Table>
      </TableContainer>
    </div>
     <div>
     <PaginationComp
       setPage={setPage}
       page={page}
       totalPage={totalPage}
       message={message}
     />
   </div>
   </div>
  );
};

export default Leave;
