import React, { useEffect, useState } from "react";
import axios from "axios";
import Popover from '@mui/material/Popover';
import Tooltip from '@mui/material/Tooltip';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import PersonPinIcon from '@mui/icons-material/PersonPin';
import PeopleOutlineIcon from '@mui/icons-material/PeopleOutline';
import SortIcon from '@mui/icons-material/Sort';
import baseUrl from "../config/baseUrl";
import google from "./Images/google.png"
import creatorImage from "./Images/creatorImage.png"
import CloseIcon from '@mui/icons-material/Close';
import "./Calendar.css";

const Calendar = () => {
  const auth = localStorage.getItem('user');
  const [calendarGoogleEvent, setGoogleCalendarEvent] = useState([]);
  const [calendarModal, setCalendarModal] = useState(false);
  const [moreButtonPopupOpen, setMoreButtonPopupOpen] = useState(false);
  const [selectedDayEvents, setSelectedDayEvents] = useState([]);
  const [eventDay, setEventDay] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const [item, setItem] = useState(null);
  const [morePopUpMeetingDialog, setMorePopUpMeetingDialog] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState(null);
  const [showTooltip, setShowTooltip] = useState(false);
  const [holidays,setHolidays] = useState([]);

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];
 
  const today = new Date();
  const currentDay = today.getDate();
  const Month = today.getMonth();
  const Year = today.getFullYear();

  const [selectedDate, setSelectedDate] = useState(currentDay);
  const [currentMonthIndex, setCurrentMonthIndex] = useState(Month);
  const [currentYear, setCurrentYear] = useState(Year);
  
  const daysInMonth = (monthIndex, year) => {
    return new Date(year, monthIndex + 1, 0).getDate();
  };
  const isLargeScreen = window.innerWidth > 600;
  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const currentMonth = months[currentMonthIndex];
  const totalDays = daysInMonth(currentMonthIndex, currentYear);

  const handleDateClick = (day, event) => {
    setSelectedDate(day);
    const dayEvents = getEventsForDay(day);
    setSelectedDayEvents(dayEvents);
    setEventDay(`${day} ${currentMonth} ${currentYear}`);
    setEventDate(new Date(currentYear, currentMonthIndex, day).toLocaleDateString());
    setAnchorEl(event.currentTarget);
    if (dayEvents.length > 2) {
      setMoreButtonPopupOpen(true);
    }
  };

  const handleNextMonth = () => {
    if (currentMonthIndex === 11) {
      setCurrentMonthIndex(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonthIndex(currentMonthIndex + 1);
    }
  };

  const handlePrevMonth = () => {
    if (currentMonthIndex === 0) {
      setCurrentMonthIndex(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonthIndex(currentMonthIndex - 1);
    }
  };

  const handleReset = () => {
    setSelectedDate(currentDay);
    setCurrentMonthIndex(Month);
    setCurrentYear(Year);
  };

  const getEventsForDay = (day) => {
    const formattedDate = `${currentYear}-${(currentMonthIndex + 1).toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`;
    return calendarGoogleEvent.filter(event => event.scheduledDate === formattedDate);
  };

  const generateCalendarDays = () => {
    const calendarDays = [];
    let firstDay = new Date(currentYear, currentMonthIndex, 1).getDay();
  
    // Add empty cells before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      calendarDays.push(<td key={`empty-${i}`} className="attendance-data"></td>);
    }
  
    // Add the actual days and events
    for (let day = 1; day <= totalDays; day++) {
      const dayEvents = getEventsForDay(day);
    const isToday = day === currentDay && currentMonthIndex === Month && currentYear === Year; 
      calendarDays.push(
        <td key={day} className={day === selectedDate ? "selected" : ""} style={{ cursor: 'pointer' }}>
          <span className={isToday ? "my-current-date" : ""} >{day}</span>
          <div className="mt-4 mb-0">
            {dayEvents.slice(0, 2).map((event, index) => (
             <div key={index} className="meeting-hover" onClick={(e) => openCalendarDialog(event, e)}>
             <div className="green-circle"></div>
             <span className="google-event">{event.scheduledOn}</span>
             <span className="google-event">{event.summary && window.innerWidth > 600 ? event.summary.split(" ").slice(0, 2).join(" ") : event.summary && window.innerWidth < 600 ? event.summary.split(" ").slice(0, 1).join(" "):""}</span>
           </div>
            ))}
            {dayEvents.length > 2 && (
              <div className="text-center mt-2">
                <button onClick={(e) => handleDateClick(day, e)} className="more-button">More</button>
              </div>
            )}
            {holidays.map((holiday, index) => (
            <div key={index} className="holiday">
              <span>{(new Date(holiday.start).getDate()==day && new Date(holiday.start).getMonth()==currentMonthIndex && new Date(holiday.start).getFullYear()==currentYear)  ? <span className="card text-white text-center" style={{backgroundColor:"green",marginTop:"5px"}}>{holiday.title}</span>:""}</span>
            </div>
          ))}
          </div>
        </td>
      );
    }
  
    // Fill remaining cells to complete the last row of the calendar
    while (calendarDays.length % 7 !== 0) {
      calendarDays.push(<td key={`empty-${calendarDays.length}`}></td>);
    }
  
    return calendarDays;
  };
  

  const allEvents = async () => {
    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      const result = await axios.get(`${baseUrl}/fetchEvent`, config);
      setGoogleCalendarEvent(result.data.Result.items);
    } catch (error) {
      console.error("Error fetching events:", error);
    }
  };
  const allHolidays = async () => {
    try {
      let config = {
        headers: {
          "Content-type": "application/json",
          accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(`${baseUrl}/allEmpUpcomingHoliday`, {}, config);
      setHolidays(result.data.result);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    allEvents();
    allHolidays();
  }, []);

  const handleCopy = (link, index) => {
    navigator.clipboard.writeText(link).then(() => {
      setCopiedIndex(index);
      setShowTooltip(true);
      setTimeout(() => {
        setShowTooltip(false);
      }, 2000);
    });
  };

  const handleCloseMoreButtonPopUp = () => {
    setMoreButtonPopupOpen(false);
  };

  const handleCloseMorePopUpMeetingDialog = () => {
    setMorePopUpMeetingDialog(false);
  };

  const openDialog = (day, event) => {
    setItem(day);
  setMorePopUpMeetingDialog(true);
  };
  const openCalendarDialog = (day, event) => {
    setItem(day);
  setCalendarModal(true);
  };
  const handleCloseCalendarDialog=()=>{
    setCalendarModal(false)
  }
  function findDay(eventDate) {
    let date = new Date(eventDate);
    let dayIndex = date.getDay()
    if (dayIndex === 0) {
      return "Sun";  // Sunday  
    } else if (dayIndex === 1) {
      return "Mon";  // Monday
    } else if (dayIndex === 2) {
      return "Tue";  // Tuesday
    } else if (dayIndex === 3) {
      return "Wed";  // Wednesday
    } else if (dayIndex === 4) {
      return "Thu";  // Thursday
    } else if (dayIndex === 5) {
      return "Fri";  // Friday
    } else if (dayIndex === 6) {
      return "Sat";  // Saturday
    } else {
      return "Invalid day";  // Just a safety net
    }
  }
  return (
    <>
      <div className="row mt-4">
        <div className="col-6">
          <p className="d-flex align-items-center">
            <i className="fa-solid fa-chevron-left next-month-button me-3" onClick={handlePrevMonth}></i>
            <span className="current-month-year">{currentMonth.toUpperCase()} - {currentYear}</span>
            <i className="fa-solid fa-chevron-right next-month-button ms-3" onClick={handleNextMonth}></i>
          </p>
        </div>
        <div className="col-6 text-end pe-5">
          <button onClick={handleReset} className="btn btn-primary">
            Today
          </button>
        </div>
      </div>
      <div className="row attendance-calendar shadow">
        <div className="attendance-calendar-right p-3">
          <table className="table outer-table">
            <thead>
              <tr>
                {daysOfWeek.map((day) => (
                  <th key={day}>{day}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {generateCalendarDays().map((day, index) =>
                index % 7 === 0 ? (
                  <tr key={index}>
                    {generateCalendarDays().slice(index, index + 7)}
                  </tr>
                ) : null
              )}
            </tbody>
          </table>
        </div>
      </div>
      {moreButtonPopupOpen && (
        <Popover
          id={moreButtonPopupOpen ? 'simple-popover' : undefined}
          open={moreButtonPopupOpen}
          anchorEl={anchorEl}
          onClose={handleCloseMoreButtonPopUp}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'center',
          }}
          transformOrigin={{
            vertical: 'center',
            horizontal: 'center',
          }}
        >
          <div className="meeting-pop-up" style={{ minWidth: "200px", minHeight: "200px",position:'relative' }}>
            <div className="pop-up-day mt-2">
              <div className="row">
                <span className="col-7 text-end">{findDay(eventDate)}</span>
                <span className="col-4 text-end">
                <div className="modal-header d-flex justify-content-end align-items-center">
                  <CloseIcon style={{fontSize:"30px",cursor:"pointer"}} onClick={handleCloseMoreButtonPopUp}/>
                </div>
                </span>
              </div>
              <div className="row text-center mt-1">
                <div className="col-12">
                  <span className="btn btn-primary" style={{ borderRadius: "50%" }}>{new Date(eventDate).getDate()}</span>
                </div>
              </div>
            </div>
            <div className="pop-up-content p-1 mt-2">
              {selectedDayEvents.map((item, index) => (
                <div className="card d-flex flex-row mt-1 p-1 pop-up-meeting-hover" key={index} style={{ flexBasis: "100%", cursor: "pointer" }} onClick={(e) => openDialog(item,e)}>
                  <span style={{
                    height: "10px",
                    width: "10px",
                    backgroundColor: "green",
                    borderRadius: "50%",
                    marginRight: "8px",
                    alignSelf:"center"
                  }}></span>
                  <div className="col-10">
                  <span className="pop-up-time">{item.scheduledOn}</span>
                  <span className="text-primary pop-up-summary ms-1">{item.summary ? item.summary.split(" ").slice(0, 2).join(" ") : ""}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Popover>
      )}
      <Popover
        id={morePopUpMeetingDialog ? 'meeting-popover' : undefined}
        open={morePopUpMeetingDialog}
        anchorEl={anchorEl}
        onClose={handleCloseMorePopUpMeetingDialog}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
        PaperProps={{
          className: 'popup-popover-custom',
          // style: { marginLeft: isLargeScreen ? '13%' : '0' }
        }}
      >
        {item ? (
          <div className="meeting-pop-up" style={{ minWidth: "350px", minHeight: "200px", position: "relative" }}>
            <div className="modal-dialog modal-dialog-scrollable">
              <div className="modal-content">
                <div className="modal-header d-flex justify-content-end align-items-center">
                  <CloseIcon style={{fontSize:"30px",cursor:"pointer"}} onClick={handleCloseMorePopUpMeetingDialog}/>
                </div>
                <div className="modal-body" style={{ height: "30%", maxWidth: "400px", padding: "16px", overflowY: "hidden" }} >
                  <div className="row p-1">
                    <div className="row">
                      <div className="col-1">
                        <i className="fa-solid fa-square text-primary fs-4 mt-1"></i>
                      </div>
                      <div className="col-8">
                        <h1 className="modal-title fs-5" id="staticBackdropLabel">
                          <span>Summary</span>
                        </h1>
                      </div>
                      <div className="col-10">
                        <p className="text-secondary small-text">{item.PopOverEventDate}</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-1 p-1">
                        <img src={google} width={25} height={25} alt="Google" />
                      </div>
                      <div className="col-10">
                        <a href="/home" style={{ textDecoration: "none" }}>
                          <div className="d-flex">
                            <p className="bg-primary ms-1 p-2 mb-0" style={{ borderRadius: "3px" }}>
                              <a href={item.hangoutLink} className="text-light" style={{ textDecoration: "none" }}>Join with Google Meet</a>
                            </p>
                          </div>
                          <p className="text-secondary">{item.hangoutLink}</p>
                        </a>
                      </div>
                      <div className="col-1 mt-2">
                        <Tooltip
                          title={showTooltip && copiedIndex === 1 ? "Copied!" : ""}
                          open={showTooltip && copiedIndex === 1}
                          arrow
                        >
                          <ContentCopyIcon
                            onClick={() => handleCopy(item.hangoutLink, 1)}
                            style={{
                              color: copiedIndex === 1 ? "green" : "inherit",
                              cursor: "pointer",
                            }}
                          />
                        </Tooltip>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 p-1">
                        <img src={creatorImage} alt="creatorImage" className="creatorImage" />
                        <span className="m-1" style={{ fontSize: "15px", fontWeight: "500", color: "rgb(92 76 76)" }}>Creator</span>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-1 ms-4">
                        <PersonPinIcon className="fs-3 text-primary" />
                      </div>
                      <div className="col-7">
                        <p className="text-secondary mb-0">{item.creator}</p>
                      </div>
                    </div>
                    <div className="row mt-2">
                      <div className="col-1 p-1">
                        <PeopleOutlineIcon className="fs-3" />
                      </div>
                      <div className="col-9">{(item.attendees).length} guest</div>
                      <div className="col-1">
                        <i className="fa-regular fa-message fs-5"></i>
                      </div>
                      <div className="col-1">
                        <i className="fa-regular fa-envelope fs-5"></i>
                      </div>
                      <div className="row">
                        <div className="col-8">
                          <p className="text-secondary small-text mb-0">{(item.attendees).length} awaiting</p>
                        </div>
                      </div>
                    </div>
                    {(item.attendees).map((attendee, index) => (
                      <div className="row mt-1" key={index}>
                        <div className="col-1 ms-4">
                          <PersonPinIcon className="fs-3 text-primary" />
                        </div>
                        <div className="col-7">
                          <p className="text-secondary mb-0">{attendee}</p>
                        </div>
                      </div>
                    ))}
                    <div className="row mt-2">
                      <div className="col-1 p-1">
                        <SortIcon className="fs-4" />
                      </div>
                      <div className="col-11 text-secondary mt-1">
                        <p>This is all about for HRIS</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </Popover>
      <Popover
        id={calendarModal ? "meeting-popover" : undefined}
        open={calendarModal}
        anchorEl={anchorEl}
        onClose={handleCloseCalendarDialog}
        anchorOrigin={{
          vertical: "center",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "center",
          horizontal:"center"
        }}
        PaperProps={{
          className: "popup-popover-customs,popup-margin",
        }}
      >
        {item && (
          <div className="meeting-pop-up" style={{ minWidth: "350px", minHeight: "200px", position: "relative" }}>
            <div className="modal-dialog modal-dialog-scrollable">
              <div className="modal-content">
                <div className="modal-header d-flex justify-content-end align-items-center">
                  <CloseIcon style={{fontSize:"30px",cursor:"pointer"}} onClick={handleCloseCalendarDialog}/>
                </div>
                <div className="modal-body" style={{ height: "30%", maxWidth: "400px", padding: "16px", overflowY: "hidden" }}>
                  <div className="row p-1">
                    <div className="row">
                      <div className="col-1">
                        <i className="fa-solid fa-square text-primary fs-4 mt-1"></i>
                      </div>
                      <div className="col-8">
                        <h1 className="modal-title fs-5" id="staticBackdropLabel">
                          <span>summary</span>
                        </h1>
                      </div>
                      <div className="row">
                        <div className="col-10">
                          <p className="text-secondary small-text">
                            {item.PopOverEventDate}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-1 p-1">
                        <img src={google} width={25} height={25} alt="Google" />
                      </div>
                      <div className="col-10">
                        <a href="/home" style={{ textDecoration: "none" }}>
                          <div className="d-flex">
                            <p className="bg-primary ms-1 p-2 mb-0" style={{ borderRadius: "3px" }}>
                              <a href={item.hangoutLink} className="text-light" style={{ textDecoration: "none" }}>
                                Join with Google Meet
                              </a>
                            </p>
                          </div>
                          <p className="text-secondary">
                            {item.hangoutLink}
                          </p>
                        </a>
                      </div>
                      <div className="col-1 mt-2">
                        <Tooltip
                          title={showTooltip && copiedIndex === 1 ? "Copied!" : ""}
                          open={showTooltip && copiedIndex === 1}
                          arrow
                        >
                          <ContentCopyIcon
                            onClick={() => handleCopy(item.hangoutLink, 1)}
                            style={{
                              color: copiedIndex === 1 ? "green" : "inherit",
                              cursor: "pointer",
                            }}
                          />
                        </Tooltip>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 p-1">
                        <img src={creatorImage} alt="creatorImage" className="creatorImage" />
                        <span className="m-1" style={{ fontSize: "15px", fontWeight: "500", color: "rgb(92 76 76)" }}>Creator</span>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-1 ms-4">
                        <PersonPinIcon className="fs-3 text-primary" />
                      </div>
                      <div className="col-7">
                        <p className="text-secondary mb-0">
                          {item.creator}
                        </p>
                      </div>
                    </div>
                    <div className="row mt-2">
                      <div className="col-1 p-1">
                        <PeopleOutlineIcon className="fs-3" />
                      </div>
                      <div className="col-9">{(item.attendees).length} guest</div>
                      <div className="col-1">
                        <i className="fa-regular fa-message fs-5"></i>
                      </div>
                      <div className="col-1">
                        <i className="fa-regular fa-envelope fs-5"></i>
                      </div>
                      <div className="row">
                        <div className="col-8">
                          <p className="text-secondary small-text mb-0">
                            {(item.attendees).length} awaiting
                          </p>
                        </div>
                      </div>
                    </div>
                    {(item.attendees).map((attendee, index) => (
                      <div className="row mt-1" key={index}>
                        <div className="col-1 ms-4">
                          <PersonPinIcon className="fs-3 text-primary" />
                        </div>
                        <div className="col-7">
                          <p className="text-secondary mb-0">
                            {attendee}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div className="row mt-2">
                      <div className="col-1 p-1">
                        <SortIcon className="fs-4" />
                      </div>
                      <div className="col-11 text-secondary mt-1">
                        <p>This is all about for HRIS</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </Popover>
    </>
  );
};
export default Calendar;
