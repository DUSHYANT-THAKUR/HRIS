
import React, { useContext, useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import UnfoldMoreIcon from "@mui/icons-material/UnfoldMore";
import Paginations from "../CommonComponentEmployee/Pagination/Pagination";
import Filter from "../CommonComponentEmployee/Filter/Filter"
import { useStateContext } from "../../context/ContextProvider";
import CircularProgress from '@mui/material/CircularProgress';
import Flag from "react-world-flags"
import baseUrl from "../config/baseUrl";
import axios from "axios";
const headCells = [
  { id: "name", numeric: false, disablePadding: true, label: "Merchant" },
  { id: "fat", numeric: true, disablePadding: false, label: "Deposits Vol." },
  { id: "carbs", numeric: false, disablePadding: false, label: "No of trans" },
  { id: "carbs", numeric: false, disablePadding: false, label: "Modes" },
  { id: "carbs", numeric: false, disablePadding: false, label: "Card/APM" },
  { id: "protein", numeric: false, disablePadding: false, label: "Currency" },
  { id: "protein", numeric: false, disablePadding: false, label: "Sell Rate" },
  { id: "protein", numeric: false, disablePadding: false, label: "Buy Rate" },
  { id: "commissions", numeric: true, disablePadding: false, label: "Net Margin" },
  { id: "commissions", numeric: true, disablePadding: false, label: "Success Vol." },
  { id: "commissions", numeric: true, disablePadding: false, label: "CB/Refund Vol." },
  { id: "commissions", numeric: true, disablePadding: false, label: "Amount for Commission" },
  { id: "commissions", numeric: true, disablePadding: false, label: "Amount for Commission in USD" },
];
function EnhancedTableHead(props) {
  const { onSelectAllClick } = props;
  return (
    <TableHead>
      <TableRow>
        <TableCell padding="checkbox" sx={{ paddingRight: 0 }}>
          <Checkbox color="primary" onChange={onSelectAllClick} />
        </TableCell>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            sx={{
              paddingLeft: headCell.id === "name" ? 0 : undefined,
              paddingRight: headCell.id === "name" ? 0 : undefined,
            }}
          >
            <TableSortLabel style={{ fontWeight: "600" }}>{headCell.label}</TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}
const Report = () => {
  const { bdmId } = useStateContext();
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(0);
  const [message, setMessage] = useState("");
  const [data, setData] = useState([]);
  const auth = localStorage.getItem('user')
  const [date, setDate] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [loading, setLoading] = useState(true);
  const [searchItem, setSearchItem] = useState("");
  const [currencyCountryMap, setcurrencyCountryMap] = useState([])
  const fatchReport = async () => {
    try {
      let formData = new FormData();
      formData.append("bdm_id", bdmId)
      formData.append("from", from);
      formData.append("to", to);
      formData.append("date", date);
      formData.append("searchitem", searchItem);
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(`${baseUrl}/defaultReport`, formData, config);
      setLoading(false)
      setData(result.data.result.result);
      setTotalPage(result.data.result.totalPage)
      setMessage(result.data.result.message)
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const fetchflag = async () => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(`${baseUrl}/flagImage`, {}, config);
      setcurrencyCountryMap(result.data.result)
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const filteredData = searchItem
  ? data.filter((row) =>
      row.ammount_type?.toLowerCase().includes(searchItem.toLowerCase())
    )
  : data;
  useEffect(() => {
    fatchReport()
    fetchflag()
  }, [from, to, date, searchItem])
  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = data.map((n) => n.id);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };
  const handleClick = (id) => {
    const selectedIndex = selected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }
    setSelected(newSelected);
  };
  const isSelected = (id) => selected.indexOf(id) !== -1;
  return (
    <div className="container-fluid report-content ps-0">
      <div className="row mt-3">
        <div className="col-12 ms-2 ms-md-0"><h5 style={{ fontSize: "24px", fontWeight: 500, color: " #5F5454", textShadow: "0.2px 0.2px 0.2px black" }}>Report</h5></div>
      </div>
      <div className="row mt-0 mt-md-3" style={{ backgroundColor: "#F8F9FA", padding: "20px 30px", boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}>
        {/* <div className="col-md-3 col-sm-6">
          <h5 className="mt-2" style={{ fontWeight: 600 }}>
            Total Commission: $10,987
          </h5>
        </div> */}
        <div className="col-12 col-md-3">
          <div className="input-group flex-nowrap mb-2">
            <span className="input-group-text" id="addon-wrapping">
              <SearchIcon />
            </span>
            <input
              type="text"
              className="form-control p-1"
              placeholder="Search"
              aria-label="Search"
              aria-describedby="addon-wrapping"
              onChange={(e) => setSearchItem(e.target.value)}
            />
          </div>
        </div>
        {/* <div className="col-6 col-md-3 text-end">
          <Filter setTo={setTo} setFrom={setFrom} setDate={setDate} />
        </div>
        <div className="col-6 col-md-6 text-end">
          <button className="btn btn-primary">Download</button>
        </div> */}
      </div>
      <div className="text-center">
        <Box sx={{ width: "100%" }}>
          <Paper
            sx={{
              width: "100%",
              boxShadow:
                "0px -5px 10px -5px rgba(0,0,0,0.3), 0px 5px 10px -5px rgba(0,0,0,0.3)",
            }}
          >
            <TableContainer className="mt-4" style={{ backgroundColor: "#f1f1f1" }} >
              <Table sx={{ minWidth: 750 }} aria-labelledby="tableTitle" size="medium">
                <EnhancedTableHead
                  numSelected={selected.length}
                  onSelectAllClick={handleSelectAllClick}
                  rowCount={data.length}
                />
                {loading ? (
                  <div style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    textAlign: "center",
                    fontSize: "18px",
                    fontWeight: "bold",
                    color: "#5d5a5a"
                  }}>
                    <CircularProgress />
                  </div>
                ) : (<TableBody>
                  {filteredData.map((row, index) => {
                    const isItemSelected = isSelected(row.id);
                    const labelId = `enhanced-table-checkbox-${index}`;
                    return (
                      <TableRow
                        hover
                        onClick={() => handleClick(row.id)}
                        role="checkbox"
                        aria-checked={isItemSelected}
                        tabIndex={-1}
                        key={row.id || index}
                        selected={isItemSelected}
                      >
                        <TableCell padding="checkbox">
                          <Checkbox
                            color="primary"
                            checked={isItemSelected}
                            inputProps={{ "aria-labelledby": labelId }}
                          />
                        </TableCell>
                        <TableCell>{row.name}</TableCell>
                        <TableCell>{Number(row.DepositVolume).toFixed(2)}</TableCell>
                        <TableCell>{row.numberOfTransaction}</TableCell>
                        <TableCell>{row.name.split(" ").includes('P2P') ? 'P2P' : 'P2C'}</TableCell>
                        <TableCell>{row.cardApm}</TableCell>
                        <TableCell>
                          {row.ammount_type}{" "}
                          {currencyCountryMap[row.ammount_type] && (
                            <Flag
                              code={currencyCountryMap[row.ammount_type]}
                              style={{ width: '30px', marginRight: '5px' }}
                            />
                          )}
                        </TableCell>
                        <TableCell>{row.payin_upi ? row.payin_upi : row.payin_wallet ? row.payin_wallet : row.payin_netbanking ? row.payin_netbanking : row.payin_qr ? row.payin_qr : row.payin_offline ? row.payin_offline : row.payin_card ? row.payin_card : 0}</TableCell>
                        <TableCell>{row.payout_amount || 0}</TableCell>
                        <TableCell>
                          {isNaN(((row.payin_upi ? row.payin_upi : row.payin_wallet ? row.payin_wallet : row.payin_netbanking ? row.payin_netbanking : row.payin_qr ? row.payin_qr : row.payin_offline ? row.payin_offline : row.payin_card ? row.payin_card : 0) - row.payout_amount).toFixed(2))
                            ? 0
                            : ((row.payin_upi ? row.payin_upi : row.payin_wallet ? row.payin_wallet : row.payin_netbanking ? row.payin_netbanking : row.payin_qr ? row.payin_qr : row.payin_offline ? row.payin_offline : row.payin_card ? row.payin_card : 0) - row.payout_amount).toFixed(2)
                          }
                        </TableCell>
                        <TableCell>{Number(row.successDeposit).toFixed(2)}</TableCell>
                        <TableCell>{Number(row.cbRefundDeposit).toFixed(2)}</TableCell>
                        <TableCell>{Number(row.successDeposit - row.cbRefundDeposit).toFixed(2)}</TableCell>
                        {/* <TableCell><span style={{  fontWeight: 'bold', color: '#333', fontSize: '16px' }}>$  </span>{Number((row.successDeposit-row.cbRefundDeposit)/row.settled_currency).toFixed(2)}</TableCell> */}
                        <TableCell>
                          <span style={{ fontWeight: 'bold', color: '#333', fontSize: '16px' }}>$ </span>
                          {isNaN((row.successDeposit - row.cbRefundDeposit) / row.settled_currency)
                            ? '0.00'
                            : ((row.successDeposit - row.cbRefundDeposit) / row.settled_currency).toFixed(2)}
                        </TableCell>
                      </TableRow>

                    );
                  })}
                </TableBody>)}
              </Table>
            </TableContainer>
          </Paper>
        </Box>
      </div>
      <div className="row">
        <Paginations page={page} setPage={setPage} totalPage={totalPage} message={message} />
      </div>
    </div>
  );
};
export default Report;