import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import Modal from './Modal/Modal'
import Content from "./DashboardSubComponent/Content/Content";
import "./Dashboard.css";
function Dashboard() {
  const location = useLocation();
  const [isSidebarVisible, setSidebarVisible] = useState(false);
  const [showModal, setShowModal] = useState(false);
  useEffect(() => {
    if (location.state && location.state.showModal) {
      setShowModal(true);
    }
  }, [location]);
  const toggleSidebar = () => {
    setSidebarVisible(!isSidebarVisible);
  };
  return (
    <div className="dashboard-container">
      <div className={`main-content ${isSidebarVisible ? "dimmed" : ""}`}>
        <Modal showModal={showModal} setShowModal={setShowModal} />
        <Content />
      </div>
    </div>
  );
}
export default Dashboard;


