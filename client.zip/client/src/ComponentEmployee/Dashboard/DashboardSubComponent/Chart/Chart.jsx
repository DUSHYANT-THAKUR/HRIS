import React, { useEffect, useState } from 'react';
import {
  Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart
} from 'recharts';
import axios from 'axios';
import CircularProgress from '@mui/material/CircularProgress';
import baseUrl from '../../../config/baseUrl';
import './Chart.css';
// Custom tooltip component
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`Revenue: $${payload[0].value}`}</p>
        <p className="intro">{label}</p>
      </div>
    );
  }
  return null;
};
const Chart = ({ totalCommissions, setTotalCommissions,todayCommission,setTodayCommission }) => {
  const [selectedView, setSelectedView] = useState('monthly');
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);
  const auth = localStorage.getItem('user');
  const fetchData = async () => {
    try {
      const config = {
        headers: {
          'Content-type': 'application/json',
          Accept: 'application/json',
          Authorization: `Bearer ${auth}`,
        },
      };
      const result = await axios.post(`${baseUrl}/commissionCalculation`, {}, config);
      const apiData = result.data.result;
      let todayData = !apiData.todays ? 0 : apiData.todays;
      setTodayCommission(todayData);
      const formattedData = {
        // weekly: apiData.weekly.map(item => ({
        //   name: item.day,
        //   revenue: parseFloat(item.commission),
        // })),
        monthly: apiData.map(item => ({
          name: item.month,
          revenue: parseFloat(item.commission),
        })),
        // yearly: apiData.yearly.map(item => ({
        //   name: item.year,
        //   revenue: parseFloat(item.commission),
        // })),
      };
      setData(formattedData);
      setLoading(false)
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  useEffect(() => {
     fetchData();
  }, []);
  useEffect(() => {
    if (data[selectedView]) {
      let totalRevenue = data[selectedView].reduce((acc, cur) => acc + cur.revenue, 0);
      totalRevenue=totalRevenue.toFixed(2)
      setTotalCommissions(totalRevenue);
    }
  }, [selectedView, data, setTotalCommissions]);
  const handleButtonClick = (view) => {
    setSelectedView(view);
  };
  return (
    <div>
      <div className="chart-container card mt-4 mb-4">
        <div className="buttons mt-4">
        <button onClick={() => handleButtonClick('monthly')}>Month</button>
          {/* <button onClick={() => handleButtonClick('weekly')}>Week</button> */}
          {/* <button onClick={() => handleButtonClick('yearly')}>Year</button> */}
        </div>  {loading ? (
        <div  style={{height:"200px",textAlign:"center",marginTop:"4%"}}>
          <CircularProgress />
        </div>
      ) : ( <div className='responsive-chart'>
        <ResponsiveContainer height={400}>
          <AreaChart
            data={data[selectedView]}
            margin={{
              top: 5, right: 20, left: 5, bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Area
              dataKey="revenue"
              stroke="#00AAFF"
              fill="#00AAFF"
              fillOpacity={0.2}
              activeDot={{ r: 8 }}
            />
          </AreaChart>
        </ResponsiveContainer>
        </div> )}
      </div>
    </div>
  );
};
export default Chart;