import React from "react";
import "./Modal.css";
import axios from "axios";
import baseUrl from "../../config/baseUrl";

const Modal = ({ showModal, setShowModal }) => {
  if (!showModal) return null; // Don't render if showModal is false

  const auth = localStorage.getItem('user')
  
  const fatchattendance = async () => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      let result = await axios.post(`${baseUrl}/login_employee`, {}, config);   
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const handleToggle = () => {
    setTimeout(() => {
      fatchattendance()
      setShowModal(false);
    }, 1000);
  };
  let today = new Date()
  let formattedDate = today.getFullYear() + '-' + (today.getMonth() + 1).toString().padStart(2, '0') + '-' + today.getDate().toString().padStart(2, '0');
  let formatted_time = today.getHours().toString().padStart(2, '0') + ':' + today.getMinutes().toString().padStart(2, '0') + ':' + today.getSeconds().toString().padStart(2, '0');

  return (
    <div
      className="modal fade show "
      style={{ display: "block", backgroundColor: "rgba(0, 0, 0, 0.5)" }} // Modal background
      tabIndex="-1"
      aria-labelledby="staticBackdropLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content ">


          <div className="row">
            {/* Left-aligned text with a bold font */}
            <div className="col-6 text-start fw-bold">😊 Have a nice day 🙋‍♂️</div>

            {/* Right-aligned text with a bold font for the date */}
            <div className="col-6 text-end fw-bold">{formattedDate}</div>
          </div>

          <div className="row">
            {/* Right-aligned text with a bold font for the time */}
            <div className="col-12 text-end fw-bold">{formatted_time}</div>
          </div>


          <div class="form-check form-switch pt-2 ">
            <label htmlFor="flexSwitchCheckDefault" className="fw-bold">
              <input
                className="form-check-input"
                type="checkbox"
                id="flexSwitchCheckDefault"
                onClick={handleToggle}
              />
              Please mark your attendance for today by clicking the button. Thank you!
            </label>

          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;
