import React, { useState, useEffect } from "react";
import "./ForgotPassword.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser, faLock } from "@fortawesome/free-solid-svg-icons";
import { faCheckCircle } from "@fortawesome/free-solid-svg-icons";
import { useNavigate, Link } from "react-router-dom";
import { toast } from "react-toastify";
import baseUrl from "../config/baseUrl";
import axios from "axios";

const ForgotPassword = () => {
  const [cmp, setCmp] = useState(0);
  const [sendingOtp, setSendingOtp] = useState("");
  const [sendingEmail, setSendingEmail] = useState("");

  const SentOTP = () => {
    const [email, setEmail] = useState("");
    const handleSentVerificationToken = async (e) => {
      try {
        e.preventDefault();
        let formData = new FormData();
        formData.append("email", email);
        const config = {
          headers: {
            "content-type": "multipart/form-data"
          },
        };
        // Make sure to construct the URL correctly
        let result = await axios.post(`${baseUrl}/sendOtpByEmail`, formData, config);
        setSendingOtp(result.data.otp)
        setSendingEmail(email)
        if (result.status === 200) {
          toast.success("OTP sent successfully!", {
            position: "bottom-right",
            autoClose: 1000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
          setCmp(cmp + 1);
        } else {
          toast.error("Entered email is not registered email", {
            position: "bottom-right",
            autoClose: 1000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      } catch (err) {
        console.error(err);
        toast.error("An error occurred while sending OTP.", {
          position: "bottom-right",
          autoClose: 1000,
        });
      }
    };

    return (
      <>
        <div className="row m-0">
          <div className="col-12 text-end mt-3">
            <span className="account-text"> Alreadey have an Account ?<Link to="/employee/login-employee" className="btn btn-primary ms-2 login-button" style={{ padding: "1px 10px" }}>Login</Link></span>
          </div>
        </div>
        <div className="sign-in-column">
          <div className="form-wrapper sign-in-form-wrapper">
            <form className="form sign-in-form" onSubmit={handleSentVerificationToken}>
              <div className="form-title text-center">Reset Password</div>

              <div className="label-field mt-5"><label>Email</label></div>

              <div className="input-field">
                <FontAwesomeIcon icon={faUser} />
                <input
                  type="email"
                  className={`form-control ${email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? 'is-invalid' : ''}`} // Bootstrap validation classes
                  placeholder="email"
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="col-12 mt-2">
            Note: Your password must be 8-20 characters long, contain letters and numbers, one of these special characters: "$@#^|!~=+-_." and must not contain spaces.
          </div>
              <button type="submit" className="btn btn-primary my-submit-button mt-4">
                Send OTP
              </button>
              <p>
                <span className="sign-up-redirect-text">Don't have an account?</span>
                <b className="pointer ms-1" style={{ color: "blue" }}>
                  <Link to="/employee/signup-employee">Sign up here</Link>
                </b>
              </p>
            </form>

          </div>
        </div>
      </>
    );
  };
  const VerifyOtp = () => {
    const [otp, setOtp] = useState("");
    const [timer, setTimer] = useState(120); // 2 minutes timer (120 seconds)
    const [isExpired, setIsExpired] = useState(false);
    const navigate = useNavigate();

    const handleInputChange = (e) => {
      const inputs = document.querySelectorAll(".otp-letter-input");
      const otpValue = Array.from(inputs).map(input => input.value).join('');
      setOtp(otpValue);
    };

    const handleVerifyOTP = async (e) => {
      e.preventDefault();
      if (isExpired) {
        navigate()
        toast.error("Your OTP has expired. Please request a new one.", {
          position: "bottom-right",
          autoClose: 1000,
        });
        return;
      } else if (sendingOtp == otp) {
        toast.success("OTP verified successfully!", {
          position: "bottom-right",
          autoClose: 1000,
        });
        setCmp(cmp + 1);
      } else {
        toast.error("Verification failed.", {
          position: "bottom-right",
          autoClose: 1000,
        });
      }
    };

    const cancelOTP = (e) => {
      e.preventDefault();
      setCmp(cmp - 1);
    };

    useEffect(() => {
      if (timer > 0) {
        const countdown = setTimeout(() => {
          setTimer(timer - 1);
        }, 1000);
        return () => clearTimeout(countdown);
      } else if (timer == 0) {
        setTimeout(() => {
          navigate("/employee/forgot-password")
        }, 1000)
      } else {
        setIsExpired(true);
      }
    }, [timer]);

    return (
      <>
        <div className="row m-0">
          <div className="col-12 text-end mt-3">
            <span className="account-text">Already have an Account? <Link to="/employee/login-employee" className="btn btn-primary ms-2 login-button" style={{ padding: "1px 10px" }}>Login</Link></span>
          </div>
        </div>
        <div className="sign-in-column">
          <div className="form-wrapper sign-in-form-wrapper">
            <div className="form sign-in-form">
              <div className="form-title text-center">OTP Verification</div>
              <div>
                <p className="text-center"><i className="fa-solid fa-envelope-circle-check text-success"></i></p>
                <p className="text-center h5">Please check your email</p>
                <p className="text-muted text-center">We've sent a code to contact@curfcode.com</p>
                <div className="row pt-4 pb-2 d-flex justify-content-center">
                  {[...Array(4)].map((_, index) => (
                    <div className="p-1" style={{width:"40px"}} key={index}>
                      <input
                        type="text"
                        className="otp-letter-input"
                        maxLength="1"
                        onChange={handleInputChange}
                        disabled={isExpired} // Disable input if expired
                      />
                    </div>
                  ))}
                </div>
                <div className="text-center">
                  {isExpired ? (
                    <p style={{ color: "red", backgroundColor: "rgb(247 247 247)" }}>Your OTP has expired.</p>
                  ) : (
                    <p className="card" style={{ fontSize: "14px", backgroundColor: "rgb(247 247 247)" }}>{`Time left: ${String(Math.floor(timer / 60)).padStart(2, '0')}:${String(timer % 60).padStart(2, '0')}`}</p>
                  )}
                </div>
                <p className="text-muted text-center">Didn't get the code? <a href="#" className="text-primary">Click to resend.</a></p>
                <div className="row pt-2">
                  <div className="col-6">
                    <button className="btn btn-outline-primary my-submit-button" onClick={cancelOTP} style={{ color: "white" }}>Cancel</button>
                  </div>
                  <div className="col-6">
                    <button className="btn btn-primary my-submit-button" onClick={handleVerifyOTP} disabled={isExpired}>Verify & Next</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };
  const SetNewPassword = () => {
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [errorMessage, setErrorMessage] = useState("");
    const [type1, setType1] = useState("password");
    const [type2, setType2] = useState("password");
    const handleVerifyVerificationToken = async (e) => {
      e.preventDefault()
      if (password != confirmPassword) {
        setErrorMessage("Password and Confirm Password do not match");
        return;
      }

      setErrorMessage("");
      let formData = new FormData();
      formData.append("email", sendingEmail);
      formData.append("password", password);
      const config = {
        headers: {
          "content-type": "multipart/form-data",
        },
      };
      let result = await axios.post(`${baseUrl}/forgotUpdatedPassword`, formData, config)
      if (result.status == 200) {
        toast.success("Updated Successfully", {
          position: "bottom-right",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        setCmp(cmp + 1);
      } else {
        toast.error("Error to Update", {
          position: "bottom-right",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    }
    const changeType1 = () => {
      setType1((preType) => (preType === "password" ? "text" : "password"));
    };
    const changeType2 = () => {
      setType2((preType) => (preType === "password" ? "text" : "password"));
    };
    return (
      <>
        <div className="row m-0">
          <div className="col-12 text-end mt-3">
            <span className="account-text"> Alreadey have an Account ?<Link to="/employee/login-employee" className="btn btn-primary ms-2 login-button" style={{ padding: "1px 10px" }}>Login</Link></span>
          </div>
        </div>
        <div className="sign-in-column">
          <div className="form-wrapper sign-in-form-wrapper">
            <div className="form sign-in-form">
              <div className="form-title text-center">Generate New Password</div>

              <div className="label-field mt-3"><label>New Password</label></div>
              <div className="input-field">
                <FontAwesomeIcon icon={faLock} />
                <input
                  type={type1}
                  placeholder="New Password"
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <img
                  src="https://www.bankconnect.online/assets/merchants/img/Eye.svg"
                  alt=" not found"
                  style={{ cursor: "pointer", height: "18px", width: "20px" }}
                  onClick={changeType1}
                />
              </div>

              <div className="label-field mt-3"><label>Confirm Password</label></div>
              <div className="input-field">
                <FontAwesomeIcon icon={faLock} />
                <input
                  type={type2}
                  placeholder="Confirm Password"
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
                <img
                  src="https://www.bankconnect.online/assets/merchants/img/Eye.svg"
                  alt=" not found"
                  style={{ cursor: "pointer", height: "18px", width: "20px" }}
                  onClick={changeType2}
                />
              </div>

              {/* Display error if passwords don't match */}
              {password !== confirmPassword && (
                <p style={{ color: "red" }}>Passwords do not match!</p>
              )}

              <button
                type="submit"
                className="btn btn-primary my-submit-button mt-4"
                disabled={password !== confirmPassword}
                onClick={handleVerifyVerificationToken}
              >
                Submit
              </button>

              <p>
                <span className="sign-up-redirect-text">Don't have an account?</span>
                <b className="pointer" style={{ color: "blue" }}>
                  <Link to="/employee/signup-employee">Sign up here</Link>
                </b>
              </p>
            </div>

          </div>
        </div>
      </>
    )
  };
  const SuccessPage = () => {
    const [timer, setTimer] = useState(15);
    const navigate = useNavigate();
  
    useEffect(() => {
      if (timer > 0) {
        const countdown = setTimeout(() => {
          setTimer((prevTimer) => prevTimer - 1);
        }, 1000);
        return () => clearTimeout(countdown);
      } else {
        navigate("/employee/login-employee");
      }
    }, [timer, navigate]);
  
    // Calculate the width based on the timer
    const progressBarWidth = `${(timer / 100) * 100}%`;
  
    return (
      <>
        <div className="row m-0">
          <div className="row m-0" style={{ background: "linear-gradient(135deg, #e0f7fa 0%, #d6dfe9 100%)" }}>
            <div className="col-12 text-end mt-3">
              <span className="account-text">Already have an Account? 
                <Link to="/employee/login-employee" className="btn btn-primary ms-2 login-button" style={{ padding: "1px 10px" }}>Login</Link>
              </span>
            </div>
          </div>
          <div className="success-container">
            <div className="success-part">
              <FontAwesomeIcon icon={faCheckCircle} className="success-icon" />
              <h3>Password Reset Successful!</h3>
              <p>You can now <Link to="/employee/login-employee">Log in</Link> with your new password.</p>
              <div className="progress-bar-container">
                <div className="progress-bar" style={{ width: progressBarWidth, backgroundColor: 'blue', height: '100%' }}></div>
              </div>
              <div className="progress-bar-description">
                You will be automatically redirected to the Login Page in {timer} seconds.
                <br />
                <span>Please wait...</span>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };

  return (
    <div>
      {cmp == 0 || cmp == 1 || cmp == 2 ? (
        <div>
          <div className="row forgot-password-container m-0">
            <div className="col-6 forgot-password-left" style={{ padding: "0px" }}>
              <div className="sign-in-text-column">
                <span className="ubankconnect-logo"></span>
                <h2 className="forgot-password-title" style={{WebkitBackgroundClip: 'text'}}>Forgot Password</h2>
                <div className="img sign-in-image"></div>
              </div>
            </div>
            <div className="col-6 forgot-password-row">
              {cmp === 0 && <SentOTP />}
              {cmp === 1 && <VerifyOtp />}
              {cmp === 2 && <SetNewPassword />}
            </div>
          </div>
        </div>
      ) : (
        <SuccessPage />
      )}
    </div>
  );
};
export default ForgotPassword;
