import React, { useEffect, useState } from "react";
import "./Sidebar.css";
import logo from "./bankconnect.6939ad8ad77f7b4fbcd4.png";
import DashboardIcon from "@mui/icons-material/Home";
import NotificationsIcon from "@mui/icons-material/Notifications";
import AttendanceIcon from "@mui/icons-material/Assignment";
import PerformanceIcon from "@mui/icons-material/BarChart";
import CalendarIcon from "@mui/icons-material/CalendarMonth";
import LibraryBooksIcon from "@mui/icons-material/LibraryBooks";
import ModelTrainingIcon from "@mui/icons-material/ModelTraining";
import EmployeesIcon from "@mui/icons-material/Groups";
import EditProfileIcon from "@mui/icons-material/ManageAccountsOutlined";
import SettingsIcon from "@mui/icons-material/Settings";
import HelpCenterIcon from "@mui/icons-material/HelpCenter";
import LogoutIcon from "@mui/icons-material/Logout";
import { useNavigate } from "react-router-dom";
import { useStateContext } from "../../context/ContextProvider";
import CloseIcon from "@mui/icons-material/Close";
import LogoutModal from "../Header/LogoutModal";
import axios from "axios";
import baseUrl from "../config/baseUrl";


const Sidebar = ({ handleToggleSidebar }) => {
  const [isMobileView, setIsMobileView] = useState(false);
  var designation = localStorage.getItem("team")
  const navigate = useNavigate();
  const { setIsLoginUser } = useStateContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const handleLogout = () => {
    setIsModalOpen(true);
  };
  const LoggedOut = () => {
    const auth = localStorage.getItem("user");
    const fatchlogoutattendance = async () => {
      try {
        const config = {
          headers: {
            "Content-type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${auth}`,
          },
        };
        let result = await axios.post(`${baseUrl}/logout_employee`, {}, config);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    setTimeout(() => {
      fatchlogoutattendance();
      setIsModalOpen(false);
      localStorage.clear("user");
      localStorage.clear("role");
      setIsLoginUser(undefined);
      navigate("/employee/login-employee");
    }, 1000);
  };
  const SidebarData = [
    {
      title: "Dashboard",
      icon: <DashboardIcon />,
      link: "/employee/dashboard",
    },
    {
      title: "Attendance",
      icon: <AttendanceIcon />,
      link: "/employee/Attendance",
    },
    {
      title: "Performance",
      icon: <PerformanceIcon />,
      link: "/employee/Performanaces",
    },
    {
      title: "My Calender",
      icon: <CalendarIcon />,
      link: "/employee/my-calender",
    },
    {
      title: "Report",
      icon: <LibraryBooksIcon />,
      link: "/employee/Report",
    },
    // {
    //     title:'Training',
    //     icon:<ModelTrainingIcon />,
    //     link:'/bankconnect/employee/Training'
    // },
    {
      title: "Employees",
      icon: <EmployeesIcon />,
      link: "/employee/Employee",
    },
    {
      title: "Edit Profile",
      icon: <EditProfileIcon />,
      link: "/employee/EditProfile",
    },
    {
      title: "Change Password",
      icon: <HelpCenterIcon />,
      link: "/employee/ChangePassword",
    },
    {
      title: "LogOut",
      icon: <LogoutIcon />,
      action: handleLogout,
    },
  ];
  const SidebarDataforTechnichalDept = [
    {
      title: "Dashboard",
      icon: <DashboardIcon />,
      link: "/employee/dashboard",
    },
    {
      title: "Attendance",
      icon: <AttendanceIcon />,
      link: "/employee/Attendance",
    },
    {
      title: "My Calender",
      icon: <CalendarIcon />,
      link: "/employee/my-calender",
    },

    {
        title:'Leave',
        icon:<ModelTrainingIcon />,
        link:'employee/Leave'
    },
    {
      title: "Employees",
      icon: <EmployeesIcon />,
      link: "/employee/Employee",
    },
    {
      title: "Edit Profile",
      icon: <EditProfileIcon />,
      link: "/employee/EditProfile",
    },
    {
      title: "Change Password",
      icon: <HelpCenterIcon />,
      link: "/employee/ChangePassword",
    },
    {
      title: "LogOut",
      icon: <LogoutIcon />,
      action: handleLogout,
    },
  ];
  const SidebarDataForVendorIntegration = [
    {
      title: "Dashboard",
      icon: <DashboardIcon />,
      link: "/employee/dashboard",
    },
    {
      title: "Attendance",
      icon: <AttendanceIcon />,
      link: "/employee/Attendance",
    },
    {
      title: "My Calender",
      icon: <CalendarIcon />,
      link: "/employee/my-calender",
    },
    {
        title:'Vendor Integration',
        icon:<ModelTrainingIcon />,
        link:'employee/VendorIntegration'
    },
    {
      title: "Employees",
      icon: <EmployeesIcon />,
      link: "/employee/Employee",
    },
    {
      title: "Edit Profile",
      icon: <EditProfileIcon />,
      link: "/employee/EditProfile",
    },
    {
      title: "Change Password",
      icon: <HelpCenterIcon />,
      link: "/employee/ChangePassword",
    },
    {
      title: "LogOut",
      icon: <LogoutIcon />,
      action: handleLogout,
    },
  ];
  const checkMobileView = () => {
    if (window.innerWidth < 1158) {
      setIsMobileView(true);
    } else {
      setIsMobileView(false);
    }
  };
  // Add event listener to detect screen resize
  useEffect(() => {
    checkMobileView(); // Initial check on mount
    window.addEventListener("resize", checkMobileView);
    // Cleanup event listener on unmount
    return () => {
      window.removeEventListener("resize", checkMobileView);
    };
  }, []);
  const SidebarSettingData = [
    // {
    //     title:'Setting',
    //     icon:<SettingsIcon/>,
    //     link:'/setting'
    // },
    // {
    //     title:'Edit Profile',
    //     icon:<SettingsIcon/>,
    //     link:'/edit-profile'
    // },
    // {
    //     title:'Change Password',
    //     icon:<HelpCenterIcon/>,
    //     link:'/bankconnect/employee/ChangePassword'
    // },
    // {
    //     title:'LogOut',
    //     icon:<LogoutIcon/>,
    //     action:LoggedOut
    // },
  ];
  console.log("my designation is ",designation)
  return (
    <div className="sidebar position-fixed">
      <div className="logo">
        <img src={logo} id="logo" />
        <CloseIcon
          onClick={handleToggleSidebar}
          className="close-icon mt-3"
        />{" "}
        {/* Close icon */}
      </div>
      <ul className="sidebarList">
  {
    
    (designation === "Junior Sales/ Junior BDM" ||
    designation === "Sales Manager/BDM" ||
    designation === "Senior Sales Manager /Senior BDM" ||
    designation === "Head of Sales & BD") 
    ? SidebarData.map((val, key) => {
        return (
          <li
            key={key}
            id={window.location.pathname === val.link ? "active" : ""}
            onClick={() => {
              if (val.action) {
                val.action();
              } else {
                navigate(val.link);
                // Hide the sidebar only if the screen is less than 1158px
                if (isMobileView) {
                  handleToggleSidebar();
                }
              }
            }}
            className="sidebar-content"
          >
            <div id="icon">{val.icon}</div>
            <div id="title" title={val.title}>
              {val.title}
            </div>
          </li>
        );
      })
    : (designation === "Senior Acquiring Manager" ||
      designation === "Acquiring Manager") 
      ? SidebarDataForVendorIntegration.map((val, key) => {
        return (
          <li
            key={key}
            id={window.location.pathname === val.link ? "active" : ""}
            onClick={() => {
              if (val.action) {
                val.action();
              } else {
                navigate(val.link);
                // Hide the sidebar only if the screen is less than 1158px
                if (isMobileView) {
                  handleToggleSidebar();
                }
              }
            }}
            className="sidebar-content"
          >
            <div id="icon">{val.icon}</div>
            <div id="title" title={val.title}>
              {val.title}
            </div>
          </li>
        );
      }) : SidebarDataforTechnichalDept.map((val, key) => {
        return (
          <li
            key={key}
            id={window.location.pathname === val.link ? "active" : ""}
            onClick={() => {
              if (val.action) {
                val.action();
              } else {
                navigate(val.link);
                // Hide the sidebar only if the screen is less than 1158px
                if (isMobileView) {
                  handleToggleSidebar();
                }
              }
            }}
            className="sidebar-content"
          >
            <div id="icon">{val.icon}</div>
            <div id="title" title={val.title}>
              {val.title}
            </div>
          </li>
        );
      })
  }
</ul>

      {isModalOpen && (
        <LogoutModal
          open={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          LoggedOut={LoggedOut}
        />
      )}
    </div>
  );
};

export default Sidebar;
