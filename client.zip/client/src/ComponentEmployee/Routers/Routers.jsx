import React, { useState, useLayoutEffect, useEffect } from "react";
import { Routes, Route, useLocation, useNavigate, Navigate } from "react-router-dom";
import Sidebar from "../Sidebar/Sidebar";
import Header from "../Header/Header";
import { useStateContext } from "../../context/ContextProvider";
import { jwtDecode } from "jwt-decode";

// Employee Dashboard
import SignUp from "../Signup/Signup";
import SignUpEndPage from "../Signup/EndPage";
import Login from "../../ComponentEmployee/Login/Login";
import ForgotPassword from "../ForgotPassword/ForgotPassword"
import Dashboard from "../../ComponentEmployee/Dashboard/Dashboard";
import Attendance from "../Attendance/Attendance";
import Performanaces from "../Performances/Performances";
import MyCalendar from "../MyCalendar/Calendar";
import Employee from "../Employee/Employee"
import Report from "../Report/Report";
import EditProfile from "../EditProfile/EditProfile";       
import ChangePassword from "../ChangePassword/ChangePassword";
import Leave from "../LeaveEmployee/Leave";
import VendorIntegration from "../VendorIntegration/VendorIntegation";


// Admin Dashboard
import AdminComponentAdd from "../../ComponentAdmin/AdminRoutes/AdminRouters"
import AdminSidebar from "../../ComponentAdmin/AdminSidebar/Sidebar"

function Routers() {
  const { isLoginUser, setIsLoginUser} = useStateContext();
  const [role,setRole] = useState("")
  const location = useLocation();
  const path = location.pathname;
  const reactNavigate = useNavigate()

  useLayoutEffect(() => {
    if (localStorage.getItem('admin')) {
      const { exp } = jwtDecode(localStorage.getItem('admin'))
      const expirationTime = (exp * 1000) - 60000
      if (Date.now() >= expirationTime) {
        localStorage.clear();
        reactNavigate('/Admin')
        return;
      }
      setIsLoginUser(localStorage.getItem('admin'))
       setRole(localStorage.getItem('role'))
    } else if (localStorage.getItem('user')) {
      const { exp } = jwtDecode(localStorage.getItem('user'))
      const expirationTime = (exp * 1000) - 60000
      if (Date.now() >= expirationTime) {
        localStorage.clear();
        reactNavigate('/employee/login-employee')
        return;
      }
      setIsLoginUser(localStorage.getItem('user'))
    }
  }, [path, isLoginUser, role]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMediumScreen, setIsMediumScreen] = useState(false);
  const handleToggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 1158) {
        setIsMediumScreen(true); // Show the menu icon on medium screens
        setIsSidebarOpen(false); // hide the sidebar on medium screens
      } else {
        setIsMediumScreen(false); // Hide the menu icon on larger screens
        setIsSidebarOpen(true); // Always show the sidebar on larger screens
      }
    };
    window.addEventListener("resize", handleResize);
    // Check the screen size when the component mounts
    handleResize();
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  return (
    <>

{isLoginUser && localStorage.getItem('role') === "-1" ? (
        <div>
          <AdminSidebar />
        </div>
      ) : isLoginUser && role == "" ? (
        <div className="Router-file d-flex">
          {isSidebarOpen && (
            <div className="sidebar-comp">
              <Sidebar handleToggleSidebar={handleToggleSidebar}/>
            </div>
          )}
          <div className="main-section">
            <Header handleToggleSidebar={handleToggleSidebar} isSidebarOpen={isSidebarOpen}/>
            <Routes>
              <Route
                path="/employee/dashboard"
                element={<Dashboard />}
              />
              <Route
                path="/employee/Attendance"
                element={<Attendance />}
              />
              <Route
                path="/employee/Performanaces"
                element={<Performanaces />}
              />
              <Route
                path="/employee/my-calender"
                element={<MyCalendar />}
              />
               <Route
                path="/employee/Report"
                element={<Report />}
              />
              <Route
                path="/employee/ChangePassword"
                element={<ChangePassword />}
              />
                <Route
                path="/employee/Employee"
                element={<Employee />}
              />
                <Route
                path="/employee/EditProfile"
                element={<EditProfile />}
              />
              <Route
                path="/employee/Leave"
                element={<Leave />}
              />
               <Route
                path="/employee/VendorIntegration"
                element={<VendorIntegration />}
              />
            </Routes>
          </div>
        </div>
      ) : (
        <Routes>
           <Route
            path="/employee/signup-employee"
            element={<SignUp />}
          />
           <Route
           path="/employee/success"
            element={<SignUpEndPage />}/>
          <Route
            path="/employee/login-employee"
            element={<Login />}
          />
           <Route path="/employee" element={<Login />} />
          <Route path="/Admin" element={<AdminComponentAdd />} />
          <Route
            path="/"
            element={<Navigate to="/employee/login-employee" />}
          />
           <Route
            path="/employee/forgot-password"
            element={<ForgotPassword />}
          />

        </Routes>
      )}
    </>
  );
}
export default Routers;
