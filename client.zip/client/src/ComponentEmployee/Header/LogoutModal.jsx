import * as React from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Button from '@mui/material/Button';
const style = {
    position: 'absolute',
    top: '50%',
    left: '47%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    pt: 2,
    px: 2,
    pb: 3,
  };
const LogoutModal = ({ LoggedOut, open, onClose }) => {
  let today = new Date();
  let formattedDate =
    today.getFullYear() +
    '-' +
    (today.getMonth() + 1).toString().padStart(2, '0') +
    '-' +
    today.getDate().toString().padStart(2, '0');
  let formatted_time =
    today.getHours().toString().padStart(2, '0') +
    ':' +
    today.getMinutes().toString().padStart(2, '0') +
    ':' +
    today.getSeconds().toString().padStart(2, '0');

  return (
    <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="logout-modal-title"
      aria-describedby="logout-modal-description"
    >
      <Box sx={{
          ...style,
          width: {
            xs: 350,  // Small screens
            sm: 450,  // Medium screens
            md: 500,  // Larger screens
          },
          border: "none",
          borderRadius:"10px"
        }}>
        <div className="row">
          <div className="col-6 text-start fw-bold">
            😊 Have a nice day 🙋‍♂️
          </div>
          <div className="col-6 text-end fw-bold">{formattedDate}</div>
        </div>
        <div className="row">
          <div className="col-12 text-end fw-bold">{formatted_time}</div>
        </div>
        <div className="form-check form-switch pt-2">
          <label htmlFor="flexSwitchCheckDefault" className="fw-bold">
            <input
              className="form-check-input"
              type="checkbox"
              id="flexSwitchCheckDefault"
              onClick={LoggedOut}
            />
            Before you log out, please mark your attendance for today by
            clicking the button. Thank you!
          </label>
        </div>
      </Box>
    </Modal>
  );
};
export default LogoutModal;
