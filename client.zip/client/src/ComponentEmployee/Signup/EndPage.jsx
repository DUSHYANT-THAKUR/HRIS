import React from 'react'
import { Link } from 'react-router-dom'

const EndPage = () => {
  return (
    <div className="text-center success-container">
    <div className="card Signupend-page p-4 mb-5">
      <div className="card-body">
        <div className="icon-wrapper mb-3">
        <i className="check-icon fas fa-check-circle"></i>
        </div>
        <h2 className="mb-3">Congratulations!</h2>
        <p>Your registration was successful! Your profile is currently under review by our admin team.<br /> Thank you for your patience!</p>
        <Link to="/employee/login-employee" className="btn btn-primary">
          Go to Home
        </Link>
      </div>
    </div>
  </div>
  )
}

export default EndPage