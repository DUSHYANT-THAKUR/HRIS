import React, { useState } from "react";
import "../Login/Login.css";
import { useNavigate, Link } from "react-router-dom";
import EndPage from "./EndPage";
import label from "../Login/images/3886130-removebg-preview.png";
import image from "../Login/images/Mask group.svg";
import DownloadIcon from '@mui/icons-material/Download';
import axios from "axios";
import baseUrl from "../config/baseUrl";
import { toast } from "react-toastify";
function SignUp() {
  const navigate = useNavigate();
  const [comp, setComp] = useState(0);
  const [token, setToken] = useState("");
  const handlePrev = () => {
    setComp(comp - 1)
  }
  const BasicDetails = () => {
    const [password, setPassword] = useState("");
    const [FullName, setFullName] = useState("");
    const [email, setEmail] = useState("");
    const [cpassword, setCPassword] = useState("");
    // const [CEmail, setCEmail] = useState("");
    const Insertbasicdetails = async () => {
      try {
        let formData = new FormData();
        formData.append("password", password);
        formData.append("fullName", FullName);
        formData.append("email", email);
        formData.append("confirmPassword", cpassword);
        const config = {
          headers: {
            "content-type": "multipart/form-data"
          },
        };
        let response = await axios.post(`${baseUrl}/signupDetails1`, formData, config);
        if (response.status == 200) {
          setComp(comp + 1)
          toast.success(<span>{response.data.message}</span>, {
            position: "bottom-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: false,
            pauseOnHover: false,
            draggable: false,
            progress: undefined,
            closeButton: false
          });
          setToken(response.data.data.token)
        } else {
          toast.error(<span>{response.data.message}</span>, {
            position: "bottom-right",
            autoClose: 1000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    const downloadFile = (data) => {
      const fileUrl = `${process.env.PUBLIC_URL}/${data}.pdf`;
      const link = document.createElement("a");
      link.href = fileUrl;
      link.download = "Sample.pdf";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    return (
      <>
        <form
          className="logindash"
          data-aos="fade-up"
          data-aos-offset="200"
          data-aos-delay="50"
          data-aos-duration="2000"
          data-aos-easing="ease-in-out"
          onSubmit={(e) => {
            e.preventDefault();
            Insertbasicdetails();
          }}
        >
          <h6 className="logintext mb-0 text-center">Basic Details</h6>
          <br />
          <div className="row px-3 mt-1">
            <div className="col-12">
              <label>Please take a moment to review this PDF prior to signing up.</label>
              <br />
              <button
                className="btn btn-primary mt-3 mb-2"
                type="button"
                onClick={() => downloadFile("Sample")}
              >
                Download PDF <DownloadIcon />
              </button>
            </div>
            <div className="col-12">
              <label className="pt-3">Full Name</label>
              <br />
              <input
                type="text"
                className="mt-2 form-control"
                value={FullName} // Changed to value
                onChange={(e) => {
                  setFullName(e.target.value);
                }}
              />
            </div>
            <div className="col-12 mt-1">
              <label className="pt-3">Email</label>
              <br />
              <input
                type="email"
                className="mt-2 form-control"
                value={email} // Changed to value
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
              />
            </div>
            {/* <div className="col-12 mt-1">
              <label>Confirm Email</label>
              <br />
              <input
                type="email"
                className="mt-2 form-control"
                value={CEmail}
                onChange={(e) => {
                  setCEmail(e.target.value);
                }}
              />
            </div> */}
            <div className="col-12 mt-1">
              <label>Password</label>
              <br />
              <input
                type="password"
                className="mt-2 form-control"
                value={password} // Changed to value
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
            </div>
            <div className="col-12 mt-1">
              <label className="pt-3">Confirm Password</label>
              <br />
              <input
                type="password"
                className="border-none mt-2 form-control"
                value={cpassword} // Changed to value
                onChange={(e) => {
                  setCPassword(e.target.value);
                }}
              />
            </div>
          </div>
          <div className="col-12 mt-2">
            Password must be 8-20 characters and can include: $@#^|!~=+-_.
          </div>
          <button className="next mt-2" type="submit">
            Next➡️
          </button>
        </form>
      </>
    );
  };
  const BasicDetails2 = () => {
    const [empid, setEmpid] = useState("");
    const [dob, setDob] = useState("");
    const [level, setlevel] = useState("");
    const [phone, setPhone] = useState("");
    const [doj, setDoj] = useState("");
    const [file, setFile] = useState(null);
    const Insertbasicdetails = async () => {
      try {
        let formData = new FormData();
        formData.append("empid", empid);
        formData.append("dob", dob);
        formData.append("level", level);
        formData.append("phone", phone);
        formData.append("doj", doj);
        formData.append("profileImage", file);
        const config = {
          headers: {
            "content-type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        };
        let response = await axios.post(`${baseUrl}/signupDetails2`, formData, config);
        if (response.status === 200) {
          setComp(comp + 1)
          toast.success(<span>{response.data.message}</span>, {
            position: "bottom-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: false,
            pauseOnHover: false,
            draggable: false,
            progress: undefined,
            closeButton: false
          });
        } else {
          toast.error(<span>{response.data.message}</span>, {
            position: "bottom-right",
            autoClose: 1000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    return (
      <>
        <form
          className="logindash"
          data-aos="fade-up"
          data-aos-offset="200"
          data-aos-delay="50"
          data-aos-duration="2000"
          data-aos-easing="ease-in-out"
          onSubmit={(e) => {
            e.preventDefault();
            Insertbasicdetails();
          }}
        >
          <h6 className="logintext text-center">Basic Details</h6>
          <br />
          <div className="row px-3">
            <div className="col-12">
              <label className="pt-3">Employee Id</label>
              <br />
              <input
                type="text"
                className="mt-1 form-control"
                value={empid} // Changed to value
                onChange={(e) => {
                  setEmpid(e.target.value);
                }}
              />
            </div>
            <div className="col-12">
              <label className="pt-3">Date Of Birth</label>
              <br />
              <input
                type="date"
                className="mt-1 form-control"
                value={dob} // Changed to value
                onChange={(e) => {
                  setDob(e.target.value);
                }}
              />
            </div>
            <div className="col-12">
              <label className="pt-3">Phone</label>
              <br />
              <input
                type="number"
                className="mt-1 form-control"
                value={phone} // Changed to value
                onChange={(e) => {
                  setPhone(e.target.value);
                }}
              />
            </div>
            <div className="col-12">
              <label className="pt-3">Date Of Joining</label>
              <br />
              <input
                type="date"
                className="mt-1 form-control"
                value={doj} // Changed to value
                onChange={(e) => {
                  setDoj(e.target.value);
                }}
              />
            </div>
            <div className="col-12">
              <label className="pt-3">Team</label>
              <br />
              <select
                className="mt-1 form-control"
                value={level} // Changed to value
                onChange={(e) => {
                  setlevel(e.target.value);
                }}
              >
                <option value="">Select Team</option>
                <option value="Junior Sales/ Junior BDM">Junior Sales/ Junior BDM</option>
                <option value="Sales Manager/BDM">Sales Manager/BDM</option>
                <option value="Senior Sales Manager /Senior BDM">Senior Sales Manager /Senior BDM</option>
                <option value="Head of Sales & BD">Head of Sales & BD</option>
                <option value="FrontEnd Developer">FrontEnd Developer</option>
                <option value="BackEnd Developer">BackEnd Developer</option>
                <option value="Operations">Operations</option>
                <option value="Management">Management</option>
              </select>
            </div>
            <div className="col-12 mt-2">
              <label htmlFor="file-upload" className="form-label">
                Profile Image
              </label>
              <div className="custom-file">
                <input
                  type="file"
                  id="file-upload"
                  className="d-none" // hide the default file input
                  name="profileImage"
                  accept="image/*"
                  onChange={(e) => setFile(e.target.files[0])}
                />
                <label htmlFor="file-upload" className="btn btn-outline-secondary w-100">
                  {file ? file.name : "Choose file"}
                </label>
              </div>
            </div>
          </div>
          <div className="d-flex">
            <button className="next mt-4 ms-1" type="button" onClick={handlePrev}>
             ⬅️Back
            </button>
            <button className="next mt-4 ms-1" type="submit">
            Next➡️
            </button>
          </div>
        </form>
      </>
    );
  };
  const ApiCredential = () => {
    const [file, setFile] = useState(null);
    const [parentid, setParentid] = useState("");
    const [SlackMemberID, setSlackMemberID] = useState("");
    const [SlackProfileURL, setSlackProfileURL] = useState("");
    const [GoogleCalenderID, setGoogleCalenderID] = useState("");

    const handleSubmit = async () => {
      try {
        const formData = new FormData();
        formData.append("parentid", parentid);
        formData.append("slack_uid", SlackMemberID);
        formData.append("slack_profile", SlackProfileURL);
        formData.append("google_calender_id", GoogleCalenderID);
        formData.append("userJson", file);

        const config = {
          headers: {
            "content-type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        };

        const response = await axios.post(`${baseUrl}/signupApiCredentials`, formData, config);

        if (response.status === 200) {
          navigate("/employee/success");
          toast.success(<span>{response.data.message}</span>, {
            position: "bottom-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: false,
            pauseOnHover: false,
            draggable: false,
            progress: undefined,
            closeButton: false,
          });
        } else {
          toast.error(<span>{response.data.message}</span>, {
            position: "bottom-right",
            autoClose: 1000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      } catch (error) {
        console.error("Error uploading file:", error);
      }
    };

    return (
      <>
        <form
          className="logindash"
          data-aos="fade-up"
          data-aos-offset="200"
          data-aos-delay="50"
          data-aos-duration="2000"
          data-aos-easing="ease-in-out"
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmit();
          }}
        >
          <h6 className="logintext text-center">API Credential Details</h6>
          <br />
          <div className="row px-3 mt-2">
            <div className="col-12">
              <label className="pt-3">Parent Id</label>
              <br />
              <input
                type="text"
                className="mt-1 form-control"
                value={parentid} // Changed to value
                onChange={(e) => {
                  setParentid(e.target.value);
                }}
              />
            </div>
            <div className="col-12">
              <label>Slack Member ID</label>
              <br />
              <input
                type="text"
                className="mt-2 form-control"
                value={SlackMemberID}
                onChange={(e) => setSlackMemberID(e.target.value)}
              />
            </div>
            <div className="col-12 mt-2">
              <label>Slack Profile URL</label>
              <br />
              <input
                type="text"
                className="mt-2 form-control"
                value={SlackProfileURL}
                onChange={(e) => setSlackProfileURL(e.target.value)}
              />
            </div>
            <div className="col-12 mt-2">
              <label>Google Calendar ID</label>
              <br />
              <input
                type="text"
                className="mt-2 form-control"
                value={GoogleCalenderID}
                onChange={(e) => setGoogleCalenderID(e.target.value)}
              />
            </div>

            <div className="col-12 mt-2">
              <label htmlFor="file-upload" className="form-label">
                Google Credentials
              </label>
              <div className="custom-file">
                <input
                  type="file"
                  id="file-upload"
                  className="d-none" // hide the default file input
                  name="userJson"
                  accept="application/json"
                  onChange={(e) => setFile(e.target.files[0])}
                />
                <label htmlFor="file-upload" className="btn btn-outline-secondary w-100">
                  {file ? file.name : "Choose file"}
                </label>
              </div>
            </div>
          </div>
          <div>
            <div className="d-flex">
              <button className="next mt-4 me-1" type="button" onClick={handlePrev}>
                ⬅️ Back
              </button>
              <button className="next mt-4 ms-1" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>
      </>
    );
  };
  return (
    <div className="container-fluid login-container">
      <header className="row ">
        <div className="col-md-6 col-sm-1">
          <div className="ubank-logo">
          </div>
        </div>
        {comp === 0 ? (
          <div className="col-md-6 d-flex header-content justify-content-end align-items-center mt-2 ">
            <span className="text1">Already have an account?</span>
            <Link
              to="/employee/login-employee"
              className="button1 border border-primary"
            >
              Login
            </Link>
          </div>
        ) : null}
      </header>
      <div className="col-md-5 ">
        {comp === 0 ? (
          <BasicDetails />
        ) : comp === 1 ? (
          <BasicDetails2 />
        ) : comp === 2 ? (
          <ApiCredential />
        ) : (
          <EndPage />
        )}
      </div>
      <div className="panels-container">
        <div className="panel left-panel">
          <div className="content">
            <img style={{ height: "90px" }} src={image} alt="Logo" />
            <p className="text-white">Better Payment Experience, Boost Your Business Sales!</p>
          </div>
          <img src={label} className="image" alt="Background" />
        </div>
      </div>
    </div>
  );
}
export default SignUp;
