import React, { useEffect, useState } from "react";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Paginations from "../CommonComponentEmployee/Pagination/Pagination";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import * as XLSX from "xlsx";
import "./Employee.css"
import Search from "../CommonComponentEmployee/Search/Search";
function Employee() {
    const [team, setTeam] = useState([]);
    const [searchItem, setSearchItem] = useState("");
    const [page, setPage] = useState(1);
    const [totalPage, setTotalPage] = useState(0);
    const [message, setMessage] = useState("");
    const auth = localStorage.getItem("user");
    const fetchTeam = async () => {
        try {
            let formData = new FormData();
            formData.append("searchitem", searchItem);
            formData.append("page", page);
            const config = {
                headers: {
                    "Content-type": "application/json",
                    Accept: "application/json",
                    Authorization: `Bearer ${auth}`,
                },
            };
            let result = await axios.post(`${baseUrl}/fetchTeam`, formData, config);
            setTeam(result.data.result);
            setTotalPage(result.data.totalPage)
            setMessage(result.data.message)
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };
    const downloadExl = async () => {
        try {
            const auth = localStorage.getItem("user");
            let formData = new FormData();
            formData.append("searchitem", searchItem);
            const config = {
                headers: {
                    "content-type": "multipart/form-data",
                    Authorization: `Bearer ${auth}`,
                },
            };
            const data = await axios.post(`${baseUrl}/downloadTeam`, formData, config);
            const workSheet = XLSX.utils.json_to_sheet(data.data.result);
            const workBook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workBook, workSheet, `employee_${Date.now()}`);
            XLSX.writeFile(workBook, `employee_${Date.now()}.xlsx`);
        } catch (err) {
            console.error("Error while downloading the file:", err);
        }
    };
    useEffect(() => {
        fetchTeam();
    }, [page, searchItem]);
    return (
        <div className="employee-content-container mt-4 me-4">
            <div className="row">
                <div className="col-12 ms-2 ms-md-0"><h5 style={{ fontWeight: '700' }}>Team Members</h5></div>
            </div>
            <div className="row mt-2">
                <div className="row search-container ms-1">
                    <div className="col-6 col-md-3">
                        <Search serchItem={searchItem} setSearchItem={setSearchItem} />
                    </div>
                    <div className="col-6 col-md-9 text-end">
                        <button className="btn btn-primary ms-2" onClick={downloadExl}>Download</button>
                    </div>
                </div>
            </div>
            <div className="row">
                <TableContainer className="tablecontainer2 mt-4">
                    <Table sx={{ minWidth: 650 }} className="table-striped table-hover" aria-label="simple table">
                        <TableHead>
                            <TableRow >
                                <TableCell className="tablefont-align">Employee ID</TableCell>
                                <TableCell className="tablefont-align">Members</TableCell>
                                {/* <TableCell className="tablefont-align">Gender</TableCell> */}
                                <TableCell className="tablefont-align">Department</TableCell>
                                <TableCell className="tablefont-align">Email Id</TableCell>
                                <TableCell className="tablefont-align">Slack Message</TableCell>
                                <TableCell className="tablefont-align">DOJ</TableCell>
                                <TableCell className="tablefont-align">DOB</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {team.map((item, index) => (
                                <TableRow
                                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                                    key={index}
                                >
                                    <TableCell align="center">{item.empid}</TableCell>
                                    <TableCell align="center">{item.name}</TableCell>
                                    <TableCell align="center">{item.team}</TableCell>

                                    <TableCell align="center">
                                        <Link to={`mailto:${item.email}`}>{item.email}</Link>
                                    </TableCell>
                                    <TableCell align="center">
                                        <button
                                            className="btn btn-primary" style={{ padding: "4px", fontSize: "small" }}
                                            onClick={() => window.open(item.slack_profile, "_blank")}
                                        >
                                            Slack Profile
                                        </button>
                                    </TableCell>
                                    <TableCell align="center">{item.doj}</TableCell>
                                    <TableCell align="center">{item.dob}</TableCell>
                                </TableRow>
                            ))}

                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
            <div className="row">
                <Paginations page={page} setPage={setPage} totalPage={totalPage} message={message} />
            </div>
        </div>
    );
}
export default Employee;