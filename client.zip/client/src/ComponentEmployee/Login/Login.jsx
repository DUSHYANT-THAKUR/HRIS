import React, { useState } from "react";
import CloseIcon from '@mui/icons-material/Close';
import { useNavigate, Link } from "react-router-dom";
import "./Login.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useStateContext } from "../../context/ContextProvider";
import { faUser, faLock } from "@fortawesome/free-solid-svg-icons";
import label from "./images/3886130-removebg-preview.png";
import image from "./images/Mask group.svg";
import axios from "axios";
import { toast } from "react-toastify";
import baseUrl from "../config/baseUrl";
import SignUp from "../Signup/Signup";
function Login() {
  const { setIsLoginUser,setDesignation } = useStateContext();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  let [message, setMessage] = useState("");

  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    let formData = new FormData();
    formData.append("email", email);
    formData.append("password", password);
    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(`${baseUrl}/login-employees`, formData, config)
      .then((response) => {
        console.log(response)
        setMessage((message = response.data.message));
        if (response.status==200) {
          toast.success(
            <span style={{ fontWeight: "bold", color: "#2626E8" }}>
              Hey {response.data.data.name}, Welcome To Ubankconnect
            </span>,
            {
              position: "top-center",
              autoClose: 2000,
            }
          );
          setTimeout(() => {
            setIsLoginUser(response.data.data.token);
            localStorage.setItem("user", response.data.data.token);
            localStorage.setItem(
              "timeZone",
              JSON.stringify({ name: "India", timeZone: "Asia/Kolkata" })
            );
            localStorage.setItem("userName", response.data.data.name);
            localStorage.setItem("team",response.data.data.team)
            navigate("/employee/dashboard", { state: { showModal: true } });
          }, 2000);
         
        } else {
          toast.error(message, {
            position: "bottom-right",
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        toast.error("Something went wrong:link::linked_paperclips:", {
          position: "bottom-right",
          autoClose: 1000,
        });
      });
  };

  return (
    
    <div className="container-fluid login-container">
      {/* Add Sign Up and Sign In Buttons */}
      <header className="row ">
          <div className="col-sm-1 col-md-6">
            <div className="ubank-logo">
              {/* <img src={ubankconnect} alt="" className=" me-auto ubank" /> */}
            </div>
          </div>
          <div className="col-md-6 d-flex header-content justify-content-end align-items-center mt-2">
            <span className="text1">
        Don't have an Account?
            </span>
            <Link to="/employee/signup-employee" className="button1 border border-primary">
              Sign Up
            </Link>
          </div>
        </header>
      <div>
        <div className="signin-signup row">
            <form className="sign-up-form" >
              <h2 className="title">Login</h2>
              <div className="input-field">
                <FontAwesomeIcon icon={faUser} />
                <input
                  type="text"
                  placeholder="Email Address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="input-field">
                <FontAwesomeIcon icon={faLock} />
                <input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <div style={{marginLeft:"230px"}}>
              <Link to="/employee/forgot-password"  style={{textDecoration:"none"}}>Forget Password</Link>
              </div>
              <button type="submit" className="btn-loggedIn solid" onClick={handleSubmit}>
                Login
              </button>
            </form>
        </div>
      </div>
      {/* Panel (Logo and Info) */}
      <div className="panels-container">
        <div className="panel left-panel">
          <div className="content">
            <img style={{ height: "90px" }} src={image} alt="Logo" />
            <p className="text-white">Better Payment Experience, Boost Your Business Sales!</p>
          </div>
          <img src={label} className="image" alt="Background" />
        </div>
      </div>
    </div>
  );
}
export default Login;