// context/ContextProvider.js
import React, { createContext, useContext, useState } from "react";
const StateContext = createContext();
function ContextProvider({ children }) {
  const [isLoginUser, setIsLoginUser] = useState(localStorage.getItem("user"));
  const [timeZoneVal, setTimeZoneVal] = useState("");
  const [messageList, setMessageList] = useState([]);
  const [bdmId,setBdmId] = useState("");
  const [profileImage,setProfileImage] = useState("")
  return (
    <StateContext.Provider
      value={{
        isLoginUser,
        setIsLoginUser,
        timeZoneVal,
        setTimeZoneVal,
        messageList,
        setMessageList,
        bdmId,
        setBdmId,
        profileImage,
        setProfileImage
      }}
    >
      {children}
    </StateContext.Provider>
  );
}

export default ContextProvider;

export const useStateContext = () => useContext(StateContext);
